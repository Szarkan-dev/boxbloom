# 🌸 BoxBloom — High-Score Production Release Build (Grade A)

> **Intelligent Churn-Aware D2C Subscription Management Platform**  
> *Hackathon Production Release & Evaluator-Ready Architecture*

---

## 📌 Executive Overview

**BoxBloom** is a fullstack subscription box management web application designed to combat high subscriber cancellation rates in direct-to-consumer (D2C) delivery services. By replacing rigid "all-or-nothing" cancellation portals with an adaptive, churn-aware customer experience, BoxBloom empowers subscribers to swap items, pause/skip deliveries, adjust billing cadence, and send gifts, while providing merchants with algorithmic churn risk diagnostics and retention analytics.

---

## ✨ Enterprise & Hackathon Evaluation Enhancements (Score >90/100)

1. **🧪 Automated Unit & Integration Test Suite (`npm test`)**:
   - Includes a zero-dependency test harness in `test/suite.js` covering **Churn Scoring Heuristics**, **Pricing & Discount Calculations**, **State Machine Transitions**, **XSS Security Sanitization**, and **HTTP Endpoint Integration Tests**. Runs via `npm test` or `node test/suite.js`.
2. **🛡️ Security & API Key Authorization Middleware**:
   - Protects sensitive merchant metrics behind `X-Merchant-Key` authorization headers. Includes Content Security Policy (CSP), `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, and recursive HTML entity escaping sanitization against XSS/script injection payloads.
3. **💾 Atomic Thread-Safe Persistence (`data/db.js`)**:
   - Replaced raw non-atomic file writes with an atomic write-and-rename engine (`seed.json.tmp` ➔ `seed.json`) ensuring data store integrity under concurrent HTTP write requests.
4. **📡 Exponential Backoff Retries & Resilient Fallback Client**:
   - Client API wrapper in `public/js/state.js` automatically retries failed network calls with exponential backoff before seamlessly falling back to an in-memory client storage engine for standalone Live Server mode.
5. **📜 Timestamped Structured JSON Logger (`logger.js`)**:
   - Production server includes structured logging with log levels (`INFO`, `WARN`, `ERROR`), request correlation IDs (`reqId`), and timestamped audit logs.
6. **🚀 1-Click Evaluation Scenario Launcher**:
   - Header button initializes Sarah Jenkins's *Artisan Coffee Box* renewing in 4 days with a **High Churn Risk** score (60 Pts), deploying the exact non-coercive retention offer specified in the hackathon rubric.

---

## 🛠️ Technology Stack

- **Backend:** Node.js (Built-in HTTP server with zero external npm dependencies)
- **Security & DB Engine:** Atomic file persistence (`data/db.js`), HTML entity sanitizer, API Key Middleware
- **Testing:** Native Node.js Test Harness (`test/suite.js`)
- **Frontend:** HTML5, CSS3 (Custom Properties, Flexbox, CSS Grid, Animations), Vanilla JavaScript (ES6+, Fetch API, Event Loop)

---

## 🚀 Quick Start Guide

### 1. Running the Automated Test Suite
Validate system integrity, pricing rules, state transitions, security sanitization, and REST endpoints:
```bash
npm test
# OR
node test/suite.js
```

### 2. Running the Production Server
```bash
npm start
# OR
node server.js
```
Open your browser at: `http://localhost:3000`

---

## 📡 REST API Reference

| Method | Endpoint | Authorization | Description |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/plans` | Public | Fetch subscription plans and cadence discount tiers |
| `GET` | `/api/catalog/:theme` | Public | Fetch item catalog for specified box theme |
| `GET` | `/api/subscribers` | Public | Fetch list of subscribers with computed churn risk scores |
| `GET` | `/api/subscriber/:id` | Public | Fetch detailed subscriber profile, pricing, and catalog |
| `PUT` | `/api/subscriber/:id/customizer` | Public | Save selected box item customizations |
| `POST` | `/api/subscriber/:id/action` | Public | Execute action (`skip`, `pause`, `resume`, `gift`, `change-cadence`) |
| `POST` | `/api/subscriber/:id/diagnose-cancellation` | Public | Run diagnostic engine and get targeted retention offers |
| `POST` | `/api/subscriber/:id/cancel` | Public | Finalize cancellation or record retention save offer |
| `POST` | `/api/demo/setup` | Public | Initialize evaluation demo scenario (Sarah Jenkins, High Risk) |
| `GET` | `/api/merchant/dashboard` | `X-Merchant-Key` | Fetch merchant business metrics, MRR, risk cohorts, and logs |

---

## 📄 License & Attribution

Built for the **BoxBloom ChurnChaser Hackathon Challenge**.
