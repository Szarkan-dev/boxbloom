/**
 * BoxBloom Automated Unit & Integration Test Suite
 * Zero-dependency Node.js test runner for evaluating churn matrix,
 * state machine transitions, pricing rules, security sanitization, and REST API endpoints.
 */

const http = require('http');
const path = require('path');
const db = require('../data/db');
const Logger = require('../logger');

let passedTests = 0;
let failedTests = 0;

function assert(condition, testName, details = '') {
  if (condition) {
    passedTests++;
    console.log(`  ✅ PASS: ${testName}`);
  } else {
    failedTests++;
    console.error(`  ❌ FAIL: ${testName} ${details ? `(${details})` : ''}`);
  }
}

// Hydrate DB for unit testing
db.loadData();

console.log(`\n=================================================`);
console.log(`🧪 Running BoxBloom Automated Test Suite...`);
console.log(`=================================================\n`);

// SECTION 1: UNIT TESTS - Churn Diagnostic Matrix
console.log(`▶ 1. Testing Churn Risk Calculation Matrix...`);

const lowRiskSub = { daysSinceLastLogin: 2, consecutiveSkips: 0, supportSentimentScore: 4.8, totalBoxesReceived: 10 };
const lowRiskResult = db.calculateChurnRisk(lowRiskSub);
assert(lowRiskResult.score === 0 && lowRiskResult.tier === 'Low', 'Low Risk Score Calculation', `Got ${lowRiskResult.score}, ${lowRiskResult.tier}`);

const medRiskSub = { daysSinceLastLogin: 15, consecutiveSkips: 1, supportSentimentScore: 4.0, totalBoxesReceived: 5 };
const medRiskResult = db.calculateChurnRisk(medRiskSub);
// 20 (inactivity) + 15 (skip) = 35 -> Medium Tier
assert(medRiskResult.score === 35 && medRiskResult.tier === 'Medium', 'Medium Risk Score Calculation', `Got ${medRiskResult.score}, ${medRiskResult.tier}`);

const highRiskSub = { daysSinceLastLogin: 35, consecutiveSkips: 2, supportSentimentScore: 2.0, totalBoxesReceived: 1 };
const highRiskResult = db.calculateChurnRisk(highRiskSub);
// 35 (inactivity) + 30 (skips) + 25 (sentiment) + 10 (tenure) = 100 -> High Tier
assert(highRiskResult.score === 100 && highRiskResult.tier === 'High', 'High Risk Score & Capping at 100', `Got ${highRiskResult.score}, ${highRiskResult.tier}`);


// SECTION 2: UNIT TESTS - Pricing & Cadence Discount Engine
console.log(`\n▶ 2. Testing Pricing & Discount Calculation Engine...`);

const monthlyPrice = db.getPlanPrice('classic', 'monthly');
assert(monthlyPrice.pricePerMonth === 39 && monthlyPrice.totalPrice === 39, 'Monthly Plan Base Price', `Got ${monthlyPrice.pricePerMonth}`);

const quarterlyPrice = db.getPlanPrice('deluxe', 'quarterly');
// Deluxe base 59, 10% discount -> Math.round(59 * 0.90) = 53 per month * 3 months = 159
assert(quarterlyPrice.pricePerMonth === 53 && quarterlyPrice.totalPrice === 159, 'Quarterly 10% Discount Calculation', `Got ${quarterlyPrice.pricePerMonth}`);


// SECTION 3: UNIT TESTS - Security & XSS Sanitization
console.log(`\n▶ 3. Testing Security & XSS Sanitization Module...`);

const maliciousString = "<script>alert('xss')</script>";
const sanitizedString = db.sanitizeString(maliciousString);
assert(!sanitizedString.includes('<script>') && sanitizedString.includes('&lt;script&gt;'), 'HTML Tag Escaping', `Got: ${sanitizedString}`);

const maliciousObject = {
  name: "John <img src=x onerror=alert(1)>",
  details: { address: "123 Main St 'OR 1=1--" }
};
const sanitizedObj = db.sanitizeObject(maliciousObject);
assert(!sanitizedObj.name.includes('<img') && sanitizedObj.details.address.includes('&#x27;OR'), 'Recursive Object Sanitization', `Got: ${JSON.stringify(sanitizedObj)}`);


// SECTION 4: INTEGRATION TESTS - HTTP Server & REST API Endpoints
console.log(`\n▶ 4. Testing HTTP Server REST Endpoints...`);

// Spin up a test instance of server.js on port 3099
process.env.PORT = '3099';
const serverInstance = require('../server');

function makeRequest(path, method = 'GET', headers = {}, body = null) {
  return new Promise((resolve, reject) => {
    const req = http.request({
      hostname: 'localhost',
      port: 3099,
      path,
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          const json = data ? JSON.parse(data) : {};
          resolve({ status: res.statusCode, body: json });
        } catch (e) {
          resolve({ status: res.statusCode, raw: data });
        }
      });
    });

    req.on('error', err => reject(err));
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

async function runIntegrationTests() {
  // Give server 100ms to listen
  await new Promise(r => setTimeout(r, 150));

  try {
    // GET /api/plans
    const plansRes = await makeRequest('/api/plans');
    assert(plansRes.status === 200 && plansRes.body.plans.length === 3, 'GET /api/plans returns 3 plan tiers');

    // GET /api/subscribers
    const subsRes = await makeRequest('/api/subscribers');
    assert(subsRes.status === 200 && subsRes.body.subscribers.length >= 25, 'GET /api/subscribers returns dataset');

    // PUT /api/subscriber/sub-101/customizer
    const customRes = await makeRequest('/api/subscriber/sub-101/customizer', 'PUT', {}, {
      planId: 'deluxe',
      selectedItemIds: ['c1', 'c2', 'c3']
    });
    assert(customRes.status === 200 && customRes.body.subscriber.planId === 'deluxe', 'PUT /api/subscriber/:id/customizer updates planId');

    // POST /api/subscriber/sub-101/action (skip)
    const skipRes = await makeRequest('/api/subscriber/sub-101/action', 'POST', {}, { action: 'skip' });
    assert(skipRes.status === 200 && skipRes.body.subscriber.status === 'Skipped', 'POST /api/subscriber/:id/action (skip)');

    // POST /api/subscriber/sub-101/diagnose-cancellation
    const diagRes = await makeRequest('/api/subscriber/sub-101/diagnose-cancellation', 'POST');
    assert(diagRes.status === 200 && diagRes.body.targetedOffers.length > 0, 'POST /api/subscriber/:id/diagnose-cancellation returns targeted offers');

    // POST /api/demo/setup
    const demoRes = await makeRequest('/api/demo/setup', 'POST');
    assert(demoRes.status === 200 && demoRes.body.churnRisk.tier === 'High', 'POST /api/demo/setup initializes evaluation scenario');

    // GET /api/merchant/dashboard (with auth key)
    const merchAuthRes = await makeRequest('/api/merchant/dashboard', 'GET', { 'X-Merchant-Key': 'boxbloom-merchant-secret' });
    assert(merchAuthRes.status === 200 && merchAuthRes.body.metrics.mrr > 0, 'GET /api/merchant/dashboard authenticated request');

    // GET /api/merchant/dashboard (unauthenticated check)
    const merchUnauthRes = await makeRequest('/api/merchant/dashboard', 'GET', { 'X-Merchant-Key': 'wrong-key' });
    assert(merchUnauthRes.status === 401, 'GET /api/merchant/dashboard blocks invalid API keys');

  } catch (err) {
    console.error('Integration test exception:', err);
    failedTests++;
  } finally {
    console.log(`\n=================================================`);
    console.log(`📊 Test Suite Execution Summary:`);
    console.log(`  Passed: ${passedTests}`);
    console.log(`  Failed: ${failedTests}`);
    console.log(`=================================================\n`);
    process.exit(failedTests > 0 ? 1 : 0);
  }
}

runIntegrationTests();
