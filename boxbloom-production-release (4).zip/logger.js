/**
 * BoxBloom Structured Logger
 * Provides timestamped JSON / formatted logging for auditability and debugging.
 */

const Logger = {
  formatMessage(level, message, meta = {}) {
    return JSON.stringify({
      timestamp: new Date().toISOString(),
      level,
      message,
      ...meta
    });
  },

  info(message, meta) {
    console.log(`[INFO] ${this.formatMessage('INFO', message, meta)}`);
  },

  warn(message, meta) {
    console.warn(`[WARN] ${this.formatMessage('WARN', message, meta)}`);
  },

  error(message, meta) {
    console.error(`[ERROR] ${this.formatMessage('ERROR', message, meta)}`);
  }
};

module.exports = Logger;
