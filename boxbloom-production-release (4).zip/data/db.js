/**
 * BoxBloom Data Store & Atomic Persistence Engine
 * Handles thread-safe persistence using atomic write-and-rename pattern,
 * input sanitization, and data integrity checks.
 */

const fs = require('fs');
const path = require('path');
const Logger = require('../logger');

const DATA_FILE = path.join(__dirname, 'seed.json');
const TEMP_FILE = path.join(__dirname, 'seed.json.tmp');

let dbData = null;
let isWriting = false;

// HTML Entity Sanitizer to prevent XSS / Script Injections
function sanitizeString(str) {
  if (typeof str !== 'string') return str;
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
}

function sanitizeObject(obj) {
  if (obj === null || obj === undefined) return obj;
  if (typeof obj === 'string') return sanitizeString(obj);
  if (Array.isArray(obj)) return obj.map(sanitizeObject);
  if (typeof obj === 'object') {
    const sanitized = {};
    for (const key of Object.keys(obj)) {
      sanitized[key] = sanitizeObject(obj[key]);
    }
    return sanitized;
  }
  return obj;
}

function loadData() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    dbData = JSON.parse(raw);
    Logger.info(`Loaded database store with ${dbData.subscribers.length} subscribers`, { file: DATA_FILE });
    return dbData;
  } catch (err) {
    Logger.error('Failed to load database store', { error: err.message });
    throw err;
  }
}

function saveData() {
  if (!dbData) return;
  try {
    // Atomic Write Pattern: Write to temp file then rename atomically
    const jsonString = JSON.stringify(dbData, null, 2);
    fs.writeFileSync(TEMP_FILE, jsonString, 'utf8');
    fs.renameSync(TEMP_FILE, DATA_FILE);
    Logger.info('Atomic data store save completed successfully');
  } catch (err) {
    Logger.error('Atomic save failed', { error: err.message });
  }
}

function getData() {
  if (!dbData) loadData();
  return dbData;
}

// Business Rules Logic
function calculateChurnRisk(subscriber) {
  let score = 0;
  const factors = [];

  // Inactivity Factor
  const days = Number(subscriber.daysSinceLastLogin) || 0;
  if (days >= 30) {
    score += 35;
    factors.push(`High inactivity (${days} days since last login) [+35 pts]`);
  } else if (days >= 15) {
    score += 20;
    factors.push(`Moderate inactivity (${days} days since last login) [+20 pts]`);
  } else if (days >= 7) {
    score += 10;
    factors.push(`Recent inactivity (${days} days since last login) [+10 pts]`);
  }

  // Consecutive Skips Factor
  const skips = Number(subscriber.consecutiveSkips) || 0;
  if (skips >= 2) {
    score += 30;
    factors.push(`Repeated skips (${skips} consecutive skipped months) [+30 pts]`);
  } else if (skips === 1) {
    score += 15;
    factors.push(`One recent skipped delivery [+15 pts]`);
  }

  // Support Sentiment Factor
  const sentiment = Number(subscriber.supportSentimentScore) || 5.0;
  if (sentiment < 2.5) {
    score += 25;
    factors.push(`Low support sentiment score (${sentiment.toFixed(1)}/5.0) [+25 pts]`);
  } else if (sentiment < 3.5) {
    score += 15;
    factors.push(`Fair support sentiment score (${sentiment.toFixed(1)}/5.0) [+15 pts]`);
  }

  // Tenure / Engagement Factor
  const boxes = Number(subscriber.totalBoxesReceived) || 0;
  if (boxes < 3) {
    score += 10;
    factors.push(`Early onboarding phase (${boxes} boxes received) [+10 pts]`);
  }

  // Cap score at 100
  score = Math.min(100, score);

  let tier = 'Low';
  if (score >= 60) tier = 'High';
  else if (score >= 30) tier = 'Medium';

  return { score, tier, factors };
}

function getPlanPrice(planId, cadenceId) {
  const data = getData();
  const plan = data.plans.find(p => p.id === planId) || data.plans[1];
  const cadence = data.cadences.find(c => c.id === cadenceId) || data.cadences[0];
  const discountMultiplier = 1 - (cadence.discountPercent / 100);
  const pricePerMonth = Math.round(plan.price * discountMultiplier);
  return { 
    basePrice: plan.price, 
    pricePerMonth, 
    totalPrice: pricePerMonth * cadence.monthsInterval, 
    cadenceName: cadence.name 
  };
}

module.exports = {
  loadData,
  saveData,
  getData,
  sanitizeObject,
  sanitizeString,
  calculateChurnRisk,
  getPlanPrice
};
