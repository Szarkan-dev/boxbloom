/**
 * BoxBloom Central State & REST API Client
 * Features exponential backoff retries, API security authorization headers,
 * and resilient client-side fallback storage engine.
 */

const State = {
  currentSubscriberId: 'sub-101',
  currentSubscriberData: null,
  allSubscribers: [],
  plans: [],
  cadences: [],
  selectedThemeKey: 'artisan-coffee',
  selectedCadenceId: 'monthly',
  customizerSelectedItems: [],
  isUsingFallback: false,

  // API Call Wrapper with Exponential Backoff Retry Logic
  async apiCall(endpoint, method = 'GET', body = null, retries = 3) {
    const isAbsolute = endpoint.startsWith('http');
    const port3000Url = isAbsolute ? endpoint : `http://localhost:3000${endpoint}`;

    const headers = {
      'Content-Type': 'application/json',
      'X-Merchant-Key': 'boxbloom-merchant-secret',
      'X-Demo-Mode': 'true'
    };

    const options = { method, headers };
    if (body) options.body = JSON.stringify(body);

    let attempt = 0;
    let lastError = null;

    while (attempt < retries) {
      try {
        const urlToFetch = this.isUsingFallback ? endpoint : port3000Url;
        const res = await fetch(urlToFetch, options);
        if (!res.ok) {
          if (res.status >= 500 && attempt < retries - 1) {
            attempt++;
            await new Promise(r => setTimeout(r, Math.pow(2, attempt) * 100));
            continue;
          }
          throw new Error(`HTTP ${res.status}`);
        }
        return await res.json();
      } catch (err) {
        lastError = err;
        attempt++;
        if (attempt < retries) {
          await new Promise(r => setTimeout(r, Math.pow(2, attempt) * 100));
        }
      }
    }

    console.warn(`API call failed after ${retries} attempts on ${endpoint}. Error:`, lastError);
    throw lastError;
  },

  // Load Initial Dataset
  async init() {
    try {
      const plansData = await this.apiCall('/api/plans');
      this.plans = plansData.plans;
      this.cadences = plansData.cadences;

      const subsData = await this.apiCall('/api/subscribers');
      this.allSubscribers = subsData.subscribers;

      if (this.allSubscribers.length > 0) {
        this.currentSubscriberId = this.allSubscribers[0].id;
      }
      await this.loadCurrentSubscriber();
      this.isUsingFallback = false;
    } catch (err) {
      console.warn('Backend server unreachable. Enabling resilient local storage engine...');
      this.isUsingFallback = true;
      this.initFallbackEngine();
    }
  },

  // Load Current Subscriber Details
  async loadCurrentSubscriber(id = null) {
    if (id) this.currentSubscriberId = id;
    if (this.isUsingFallback) return this.fallbackGetSubscriber(this.currentSubscriberId);

    try {
      const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}`);
      this.currentSubscriberData = res;
      this.selectedThemeKey = res.subscriber.theme;
      this.selectedCadenceId = res.subscriber.cadenceId;
      this.customizerSelectedItems = [...res.subscriber.selectedItemIds];
      return res;
    } catch (err) {
      this.isUsingFallback = true;
      return this.fallbackGetSubscriber(this.currentSubscriberId);
    }
  },

  // Save Box Customization
  async saveCustomization(itemIds) {
    if (this.isUsingFallback) return this.fallbackSaveCustomization(itemIds);

    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/customizer`, 'PUT', {
      selectedItemIds: itemIds,
      theme: this.selectedThemeKey
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Action: Skip, Pause, Resume, Gift, Change Cadence
  async performAction(action, payload = {}) {
    if (this.isUsingFallback) return this.fallbackPerformAction(action, payload);

    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/action`, 'POST', {
      action,
      ...payload
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Churn Prevention Diagnosis
  async diagnoseCancellation() {
    if (this.isUsingFallback) return this.fallbackDiagnoseCancellation();
    return await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/diagnose-cancellation`, 'POST');
  },

  // Finalize Cancellation or Accept Offer
  async processCancellation(acceptedOffer = null) {
    if (this.isUsingFallback) return this.fallbackProcessCancellation(acceptedOffer);

    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/cancel`, 'POST', {
      acceptedOffer
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Launch Hackathon Evaluation Demo Scenario
  async setupDemoScenario() {
    if (this.isUsingFallback) return this.fallbackSetupDemoScenario();

    const res = await this.apiCall('/api/demo/setup', 'POST');
    this.currentSubscriberId = 'sub-101';
    await this.loadCurrentSubscriber();
    return res;
  },

  // Submit Rating
  async submitRating(itemId, rating) {
    if (this.isUsingFallback) return this.fallbackSubmitRating(itemId, rating);

    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/rating`, 'POST', {
      itemId,
      rating
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Fetch Merchant Dashboard Metrics
  async fetchMerchantDashboard() {
    if (this.isUsingFallback) return this.fallbackGetMerchantDashboard();
    return await this.apiCall('/api/merchant/dashboard');
  },

  /* --------------------------------------------------------------------------
     RESILIENT LOCAL STORAGE FALLBACK ENGINE (For Offline / Live Server Mode)
     -------------------------------------------------------------------------- */
  initFallbackEngine() {
    this.plans = [
      { id: "mini", name: "Mini Starter", price: 19, itemCount: 3, description: "Essentials discovery.", popular: false },
      { id: "classic", name: "Classic Bloom", price: 39, itemCount: 5, description: "Balanced box experience.", popular: true },
      { id: "deluxe", name: "Deluxe Reserve", price: 59, itemCount: 7, description: "Luxury box curation.", popular: false }
    ];
    this.cadences = [
      { id: "monthly", name: "Monthly", discountPercent: 0, monthsInterval: 1 },
      { id: "bimonthly", name: "Every 2 Months", discountPercent: 5, monthsInterval: 2 },
      { id: "quarterly", name: "Every 3 Months", discountPercent: 10, monthsInterval: 3 }
    ];
    this.allSubscribers = [
      {
        id: "sub-101",
        name: "Sarah Jenkins",
        email: "sarah.j@example.com",
        theme: "artisan-coffee",
        planId: "classic",
        cadenceId: "monthly",
        status: "Active",
        daysSinceLastLogin: 18,
        consecutiveSkips: 1,
        totalBoxesReceived: 10,
        supportSentimentScore: 2.2,
        selectedItemIds: ["c1", "c2", "c4", "c7", "c8"],
        nextRenewalDate: "2026-11-23",
        packingCutoffDate: "2026-11-21",
        itemRatings: { c1: 5, c2: 4 }
      }
    ];
    this.currentSubscriberId = "sub-101";
    this.loadCurrentSubscriber("sub-101");
  },

  fallbackGetSubscriber(id) {
    const sub = this.allSubscribers.find(s => s.id === id) || this.allSubscribers[0];
    const riskScore = (sub.daysSinceLastLogin >= 15 ? 20 : 0) + (sub.consecutiveSkips >= 1 ? 15 : 0) + (sub.supportSentimentScore < 2.5 ? 25 : 0);
    const riskTier = riskScore >= 60 ? 'High' : (riskScore >= 30 ? 'Medium' : 'Low');

    const res = {
      subscriber: sub,
      plan: this.plans.find(p => p.id === sub.planId) || this.plans[1],
      pricing: { basePrice: 39, pricePerMonth: 39, totalPrice: 39, cadenceName: 'Monthly' },
      catalog: {
        name: "Artisan Coffee Roasters",
        items: [
          { id: "c1", name: "Ethiopian Yirgacheffe", category: "Light Roast", rating: 4.8, tag: "Top Rated", image: "☕" },
          { id: "c2", name: "Guatemalan Antigua", category: "Medium Roast", rating: 4.7, tag: "Popular", image: "☕" },
          { id: "c3", name: "Sumatra Mandheling", category: "Dark Roast", rating: 4.6, tag: "Bold", image: "☕" },
          { id: "c4", name: "Colombian Supremo", category: "Medium Roast", rating: 4.9, tag: "Organic", image: "🌿" },
          { id: "c7", name: "Hand-carved Scoop", category: "Accessory", rating: 4.9, tag: "Crafted", image: "🥄" },
          { id: "c8", name: "Cone Filters (100x)", category: "Accessory", rating: 4.8, tag: "Essential", image: "📄" }
        ]
      },
      churnRisk: { score: riskScore, tier: riskTier, factors: [`Inactivity (${sub.daysSinceLastLogin} days)`, `Skips (${sub.consecutiveSkips})`, `Support Sentiment (${sub.supportSentimentScore}/5.0)`] }
    };

    this.currentSubscriberData = res;
    this.selectedThemeKey = sub.theme;
    this.selectedCadenceId = sub.cadenceId;
    this.customizerSelectedItems = [...sub.selectedItemIds];
    return res;
  },

  fallbackSaveCustomization(itemIds) {
    const sub = this.allSubscribers.find(s => s.id === this.currentSubscriberId);
    if (sub) {
      sub.selectedItemIds = itemIds;
      sub.theme = this.selectedThemeKey;
    }
    return this.fallbackGetSubscriber(this.currentSubscriberId);
  },

  fallbackPerformAction(action, payload) {
    const sub = this.allSubscribers.find(s => s.id === this.currentSubscriberId);
    if (sub) {
      if (action === 'skip') { sub.status = 'Skipped'; sub.consecutiveSkips++; }
      else if (action === 'pause') { sub.status = 'Paused'; }
      else if (action === 'resume') { sub.status = 'Active'; sub.consecutiveSkips = 0; }
    }
    return this.fallbackGetSubscriber(this.currentSubscriberId);
  },

  fallbackDiagnoseCancellation() {
    const sub = this.allSubscribers.find(s => s.id === this.currentSubscriberId);
    return {
      subscriberId: sub.id,
      churnRisk: { score: 60, tier: 'High', factors: ['High inactivity (18 days)', 'One recent skip', 'Low support sentiment (2.2/5.0)'] },
      targetedOffers: [
        { id: 'offer-skip-free', title: '☕ Skip October Box & Keep 15% VIP Discount', description: 'Take a 30-day break with zero charge and retain your existing locked-in price tier.', action: 'skip' }
      ]
    };
  },

  fallbackProcessCancellation(acceptedOffer) {
    const sub = this.allSubscribers.find(s => s.id === this.currentSubscriberId);
    if (acceptedOffer) {
      sub.status = 'Skipped';
      sub.consecutiveSkips = 1;
    } else {
      sub.status = 'Cancelled';
    }
    return { message: 'Processed successfully in fallback mode' };
  },

  fallbackSetupDemoScenario() {
    const sub = this.allSubscribers[0];
    sub.status = 'Active';
    sub.daysSinceLastLogin = 18;
    sub.consecutiveSkips = 1;
    sub.supportSentimentScore = 2.2;
    return this.fallbackGetSubscriber(sub.id);
  },

  fallbackSubmitRating(itemId, rating) {
    const sub = this.allSubscribers.find(s => s.id === this.currentSubscriberId);
    if (sub) {
      if (!sub.itemRatings) sub.itemRatings = {};
      sub.itemRatings[itemId] = rating;
    }
    return this.fallbackGetSubscriber(this.currentSubscriberId);
  },

  fallbackGetMerchantDashboard() {
    return {
      metrics: {
        totalSubscribers: 25, activeSubscribers: 20, pausedSubscribers: 2, skippedSubscribers: 2, cancelledSubscribers: 1,
        mrr: 847, arpu: 42, churnRate: '4.0%', retentionSaveRate: '85.0%',
        riskCounts: { Low: 15, Medium: 6, High: 4 }
      },
      retentionInterventions: [
        { subscriberName: 'Sarah Jenkins', actionTaken: 'Retained', offerApplied: '☕ Skip October Box & Keep 15% VIP Discount', timestamp: new Date().toISOString() }
      ],
      subscribers: this.allSubscribers
    };
  }
};
