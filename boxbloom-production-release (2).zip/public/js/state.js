/**
 * BoxBloom Central State & Dual-Engine Client
 * Auto-detects Node.js REST Server (Port 3000) or seamlessly switches to
 * embedded Client Data Engine when opened via Live Server (Port 5500/8080/file).
 */

const DEFAULT_SEED_DATA = {
  plans: [
    { id: "mini", name: "Mini Starter", price: 19, itemCount: 3, description: "Perfect for essentials & quick monthly discovery.", popular: false },
    { id: "classic", name: "Classic Bloom", price: 39, itemCount: 5, description: "Our most popular balanced monthly box experience.", popular: true },
    { id: "deluxe", name: "Deluxe Reserve", price: 59, itemCount: 7, description: "Ultimate luxury box loaded with premium selections.", popular: false }
  ],
  cadences: [
    { id: "monthly", name: "Monthly", discountPercent: 0, monthsInterval: 1 },
    { id: "bimonthly", name: "Every 2 Months", discountPercent: 5, monthsInterval: 2 },
    { id: "quarterly", name: "Every 3 Months", discountPercent: 10, monthsInterval: 3 }
  ],
  catalogs: {
    "artisan-coffee": {
      name: "Artisan Coffee Roasters",
      description: "Hand-picked single origins and micro-lot roasts.",
      items: [
        { id: "c1", name: "Ethiopian Yirgacheffe", category: "Light Roast", rating: 4.8, tag: "Top Rated", image: "☕" },
        { id: "c2", name: "Guatemalan Antigua", category: "Medium Roast", rating: 4.7, tag: "Customer Favorite", image: "☕" },
        { id: "c3", name: "Sumatra Mandheling", category: "Dark Roast", rating: 4.6, tag: "Bold & Rich", image: "☕" },
        { id: "c4", name: "Colombian Supremo Organic", category: "Medium Roast", rating: 4.9, tag: "Organic", image: "🌿" },
        { id: "c5", name: "Cold Brew Coarse Blend", category: "Specialty", rating: 4.5, tag: "Seasonal", image: "🧊" },
        { id: "c6", name: "French Roast Espresso", category: "Dark Roast", rating: 4.4, tag: "Intense", image: "☕" },
        { id: "c7", name: "Hand-carved Wooden Scoop", category: "Accessory", rating: 4.9, tag: "Crafted", image: "🥄" },
        { id: "c8", name: "Unbleached Cone Filters (100x)", category: "Accessory", rating: 4.8, tag: "Essential", image: "📄" }
      ]
    },
    "gourmet-snacks": {
      name: "Gourmet Snacks",
      description: "Artisanal, non-GMO sweet and savory bites.",
      items: [
        { id: "s1", name: "Truffle & Sea Salt Almonds", category: "Savory", rating: 4.9, tag: "Best Seller", image: "🥜" },
        { id: "s2", name: "Dark Chocolate Matcha Bites", category: "Sweet", rating: 4.8, tag: "Antioxidant", image: "🍫" },
        { id: "s3", name: "Organic Dried Mango Strips", category: "Fruity", rating: 4.7, tag: "No Sugar Added", image: "🥭" },
        { id: "s4", name: "Smoked Paprika Cashews", category: "Savory", rating: 4.6, tag: "Spicy", image: "🌶️" },
        { id: "s5", name: "Artisanal Grass-Fed Jerky", category: "Protein", rating: 4.8, tag: "High Protein", image: "🥩" },
        { id: "s6", name: "Freeze-Dried Strawberry Crunch", category: "Sweet", rating: 4.5, tag: "Crispy", image: "🍓" },
        { id: "s7", name: "Gluten-Free Oats & Honey Cluster", category: "Granola", rating: 4.7, tag: "Gluten-Free", image: "🍯" },
        { id: "s8", name: "Spiced Rosemary Pecan Mix", category: "Savory", rating: 4.9, tag: "Gourmet", image: "🌿" }
      ]
    },
    "eco-grooming": {
      name: "Eco-Grooming",
      description: "Zero-waste, natural self-care & personal essentials.",
      items: [
        { id: "g1", name: "Bamboo Toothbrush Pack (4x)", category: "Dental", rating: 4.8, tag: "Biodegradable", image: "🪥" },
        { id: "g2", name: "Tea Tree Oil Shampoo Bar", category: "Haircare", rating: 4.7, tag: "Plastic-Free", image: "🧼" },
        { id: "g3", name: "All-Natural Citrus Deodorant", category: "Body", rating: 4.6, tag: "Aluminum-Free", image: "🍋" },
        { id: "g4", name: "Organic Jojoba Facial Serum", category: "Skincare", rating: 4.9, tag: "Cold-Pressed", image: "💧" },
        { id: "g5", name: "Natural Konjac Cleansing Sponge", category: "Skincare", rating: 4.8, tag: "Gentle Exfoliant", image: "🧽" },
        { id: "g6", name: "Eucalyptus Mint Lip Balm", category: "Lip Care", rating: 4.7, tag: "Organic Shea", image: "💄" },
        { id: "g7", name: "Recycled Aluminum Safety Razor", category: "Shaving", rating: 4.9, tag: "Zero Waste", image: "🪒" },
        { id: "g8", name: "Charcoal Detox Soap Bar", category: "Body", rating: 4.7, tag: "Purifying", image: "🫧" }
      ]
    }
  },
  retentionInterventions: [
    {
      id: "int-1001",
      subscriberId: "sub-103",
      subscriberName: "Elena Rostova",
      timestamp: "2026-11-15T14:30:00Z",
      riskScore: 65,
      riskTier: "High",
      actionTaken: "Retained",
      offerApplied: "20% Off Next 3 Boxes + Free VIP Mystery Snack/Accessory",
      note: "Subscriber accepted retention offer"
    },
    {
      id: "int-1002",
      subscriberId: "sub-104",
      subscriberName: "David Chen",
      timestamp: "2026-11-10T09:15:00Z",
      riskScore: 75,
      riskTier: "High",
      actionTaken: "Cancelled",
      offerApplied: "Declined all retention offers",
      note: "Proceeded with cancellation"
    }
  ],
  subscribers: [
    {
      id: "sub-101",
      name: "Sarah Jenkins",
      email: "sarah.j@example.com",
      theme: "artisan-coffee",
      planId: "classic",
      cadenceId: "monthly",
      status: "Active",
      signupDate: "2026-01-15",
      daysSinceLastLogin: 2,
      consecutiveSkips: 0,
      totalBoxesReceived: 10,
      supportSentimentScore: 4.8,
      selectedItemIds: ["c1", "c2", "c4", "c7", "c8"],
      giftingDetails: null,
      nextRenewalDate: "2026-11-23",
      packingCutoffDate: "2026-11-21",
      itemRatings: { "c1": 5, "c2": 4, "c4": 5 }
    },
    {
      id: "sub-102",
      name: "Marcus Vance",
      email: "m.vance@example.com",
      theme: "gourmet-snacks",
      planId: "deluxe",
      cadenceId: "bimonthly",
      status: "Active",
      signupDate: "2026-03-01",
      daysSinceLastLogin: 5,
      consecutiveSkips: 0,
      totalBoxesReceived: 6,
      supportSentimentScore: 4.9,
      selectedItemIds: ["s1", "s2", "s3", "s4", "s5", "s7", "s8"],
      giftingDetails: null,
      nextRenewalDate: "2026-12-01",
      packingCutoffDate: "2026-11-28",
      itemRatings: { "s1": 5, "s3": 5 }
    },
    {
      id: "sub-103",
      name: "Elena Rostova",
      email: "elena.r@example.com",
      theme: "eco-grooming",
      planId: "classic",
      cadenceId: "monthly",
      status: "Skipped",
      signupDate: "2025-11-10",
      daysSinceLastLogin: 18,
      consecutiveSkips: 2,
      totalBoxesReceived: 12,
      supportSentimentScore: 3.2,
      selectedItemIds: ["g1", "g2", "g4", "g6", "g7"],
      giftingDetails: null,
      nextRenewalDate: "2026-12-15",
      packingCutoffDate: "2026-12-13",
      itemRatings: {}
    },
    {
      id: "sub-104",
      name: "David Chen",
      email: "david.c@example.com",
      theme: "artisan-coffee",
      planId: "mini",
      cadenceId: "monthly",
      status: "Cancelled",
      signupDate: "2026-02-14",
      daysSinceLastLogin: 45,
      consecutiveSkips: 3,
      totalBoxesReceived: 2,
      supportSentimentScore: 1.8,
      selectedItemIds: ["c1", "c3", "c6"],
      giftingDetails: null,
      nextRenewalDate: null,
      packingCutoffDate: null,
      itemRatings: {}
    },
    {
      id: "sub-105",
      name: "Chloe Bennett",
      email: "chloe.b@example.com",
      theme: "gourmet-snacks",
      planId: "classic",
      cadenceId: "quarterly",
      status: "Paused",
      signupDate: "2026-05-20",
      daysSinceLastLogin: 12,
      consecutiveSkips: 1,
      totalBoxesReceived: 4,
      supportSentimentScore: 4.1,
      selectedItemIds: ["s1", "s2", "s5", "s6", "s8"],
      giftingDetails: null,
      nextRenewalDate: "2027-01-10",
      packingCutoffDate: "2027-01-08",
      itemRatings: {}
    }
  ]
};

const State = {
  currentSubscriberId: 'sub-101',
  currentSubscriberData: null,
  allSubscribers: [],
  plans: [],
  cadences: [],
  selectedThemeKey: 'artisan-coffee',
  selectedCadenceId: 'monthly',
  customizerSelectedItems: [],
  isBackendLive: false,
  clientDb: null,

  // Compute target API host (redirects static Live Server to port 3000 if active)
  getApiBaseUrl() {
    if (typeof window === 'undefined') return '';
    const isFile = window.location.protocol === 'file:';
    const port = window.location.port;
    if (isFile || (port && port !== '3000')) {
      return 'http://localhost:3000';
    }
    return '';
  },

  // Dual-Engine API Client
  async apiCall(endpoint, method = 'GET', body = null) {
    const apiBase = this.getApiBaseUrl();
    const targetUrl = apiBase ? `${apiBase}${endpoint}` : endpoint;

    const options = {
      method,
      headers: { 'Content-Type': 'application/json' }
    };
    if (body) options.body = JSON.stringify(body);

    try {
      const res = await fetch(targetUrl, options);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      this.isBackendLive = true;
      return data;
    } catch (err) {
      console.warn(`[BoxBloom] Server API unreachable at ${targetUrl}. Falling back to client-side engine.`);
      this.isBackendLive = false;
      return await this.clientDbCall(endpoint, method, body);
    }
  },

  // Hydrate Client Database from localStorage or seed.json
  async ensureClientDbLoaded() {
    if (this.clientDb) return;
    const stored = localStorage.getItem('boxbloom_db_v1');
    if (stored) {
      try {
        this.clientDb = JSON.parse(stored);
        return;
      } catch (e) {}
    }

    try {
      const res = await fetch('data/seed.json');
      if (res.ok) {
        this.clientDb = await res.json();
        localStorage.setItem('boxbloom_db_v1', JSON.stringify(this.clientDb));
        return;
      }
    } catch (e) {}

    // Fallback embedded dataset if static fetch is restricted
    this.clientDb = JSON.parse(JSON.stringify(DEFAULT_SEED_DATA));
    localStorage.setItem('boxbloom_db_v1', JSON.stringify(this.clientDb));
  },

  // Client Data Engine (Handles static/Live Server execution without Node server)
  async clientDbCall(endpoint, method = 'GET', body = null) {
    await this.ensureClientDbLoaded();
    const urlPath = endpoint.split('?')[0];

    const calcRisk = (s) => {
      let score = 0;
      const factors = [];
      const days = s.daysSinceLastLogin || 0;
      if (days >= 30) { score += 35; factors.push(`High inactivity (${days} days)`); }
      else if (days >= 15) { score += 20; factors.push(`Moderate inactivity (${days} days)`); }
      else if (days >= 7) { score += 10; factors.push(`Recent inactivity (${days} days)`); }

      const skips = s.consecutiveSkips || 0;
      if (skips >= 2) { score += 30; factors.push(`Repeated skips (${skips} months)`); }
      else if (skips === 1) { score += 15; factors.push(`One recent skip`); }

      const sentiment = s.supportSentimentScore || 5.0;
      if (sentiment < 2.5) { score += 25; factors.push(`Low support sentiment (${sentiment.toFixed(1)}/5.0)`); }
      else if (sentiment < 3.5) { score += 15; factors.push(`Fair support sentiment (${sentiment.toFixed(1)}/5.0)`); }

      if ((s.totalBoxesReceived || 0) < 3) { score += 10; factors.push(`Early onboarding phase`); }
      score = Math.min(100, score);
      let tier = 'Low';
      if (score >= 60) tier = 'High';
      else if (score >= 30) tier = 'Medium';
      return { score, tier, factors };
    };

    const getPrice = (planId, cadenceId) => {
      const plan = this.clientDb.plans.find(p => p.id === planId) || this.clientDb.plans[1];
      const cadence = this.clientDb.cadences.find(c => c.id === cadenceId) || this.clientDb.cadences[0];
      const mult = 1 - (cadence.discountPercent / 100);
      const ppm = Math.round(plan.price * mult);
      return { basePrice: plan.price, pricePerMonth: ppm, totalPrice: ppm * cadence.monthsInterval, cadenceName: cadence.name };
    };

    const saveDb = () => {
      try { localStorage.setItem('boxbloom_db_v1', JSON.stringify(this.clientDb)); } catch(e){}
    };

    // GET /api/plans
    if (method === 'GET' && urlPath === '/api/plans') {
      return { plans: this.clientDb.plans, cadences: this.clientDb.cadences };
    }

    // GET /api/catalog/:theme
    if (method === 'GET' && urlPath.startsWith('/api/catalog/')) {
      const themeKey = urlPath.split('/')[3];
      return this.clientDb.catalogs[themeKey] || this.clientDb.catalogs['artisan-coffee'];
    }

    // GET /api/subscribers
    if (method === 'GET' && urlPath === '/api/subscribers') {
      const list = this.clientDb.subscribers.map(sub => {
        const risk = calcRisk(sub);
        const pricing = getPrice(sub.planId, sub.cadenceId);
        return { ...sub, churnRiskScore: risk.score, churnRiskTier: risk.tier, riskFactors: risk.factors, monthlyRevenue: pricing.pricePerMonth };
      });
      return { subscribers: list };
    }

    // GET /api/subscriber/:id
    if (method === 'GET' && urlPath.startsWith('/api/subscriber/')) {
      const parts = urlPath.split('/');
      if (parts.length === 4 && parts[2] === 'subscriber') {
        const id = parts[3];
        const sub = this.clientDb.subscribers.find(s => s.id === id) || this.clientDb.subscribers[0];
        const risk = calcRisk(sub);
        const pricing = getPrice(sub.planId, sub.cadenceId);
        const catalog = this.clientDb.catalogs[sub.theme];
        const plan = this.clientDb.plans.find(p => p.id === sub.planId);
        return { subscriber: sub, plan, pricing, catalog, churnRisk: risk };
      }
    }

    // PUT /api/subscriber/:id/customizer
    if (method === 'PUT' && urlPath.match(/^\/api\/subscriber\/[^\/]+\/customizer$/)) {
      const id = urlPath.split('/')[3];
      const sub = this.clientDb.subscribers.find(s => s.id === id);
      if (sub && body) {
        if (body.selectedItemIds) sub.selectedItemIds = body.selectedItemIds;
        if (body.planId) sub.planId = body.planId;
        if (body.theme) sub.theme = body.theme;
        saveDb();
      }
      return { message: 'Box customization saved successfully', subscriber: sub };
    }

    // POST /api/subscriber/:id/action
    if (method === 'POST' && urlPath.match(/^\/api\/subscriber\/[^\/]+\/action$/)) {
      const id = urlPath.split('/')[3];
      const sub = this.clientDb.subscribers.find(s => s.id === id);
      if (sub && body) {
        const action = body.action;
        if (action === 'skip') {
          sub.status = 'Skipped';
          sub.consecutiveSkips = (sub.consecutiveSkips || 0) + 1;
          const cur = sub.nextRenewalDate ? new Date(sub.nextRenewalDate) : new Date();
          cur.setDate(cur.getDate() + 30);
          sub.nextRenewalDate = cur.toISOString().split('T')[0];
          const cutoff = new Date(cur); cutoff.setDate(cutoff.getDate() - 2);
          sub.packingCutoffDate = cutoff.toISOString().split('T')[0];
        } else if (action === 'pause') {
          sub.status = 'Paused';
          const cur = sub.nextRenewalDate ? new Date(sub.nextRenewalDate) : new Date();
          cur.setDate(cur.getDate() + (body.days || 30));
          sub.nextRenewalDate = cur.toISOString().split('T')[0];
          const cutoff = new Date(cur); cutoff.setDate(cutoff.getDate() - 2);
          sub.packingCutoffDate = cutoff.toISOString().split('T')[0];
        } else if (action === 'resume') {
          sub.status = 'Active';
          sub.consecutiveSkips = 0;
          const cur = new Date(); cur.setDate(cur.getDate() + 14);
          sub.nextRenewalDate = cur.toISOString().split('T')[0];
          const cutoff = new Date(cur); cutoff.setDate(cutoff.getDate() - 2);
          sub.packingCutoffDate = cutoff.toISOString().split('T')[0];
        } else if (action === 'gift') {
          sub.giftingDetails = { recipientName: body.recipientName || 'Friend', recipientAddress: body.recipientAddress || '123 Sunshine Way', giftMessage: body.giftMessage || 'Enjoy!' };
        } else if (action === 'change-cadence') {
          if (body.cadenceId) sub.cadenceId = body.cadenceId;
        }
        saveDb();
      }
      return { message: `Action processed`, subscriber: sub };
    }

    // POST /api/subscriber/:id/diagnose-cancellation
    if (method === 'POST' && urlPath.match(/^\/api\/subscriber\/[^\/]+\/diagnose-cancellation$/)) {
      const id = urlPath.split('/')[3];
      const sub = this.clientDb.subscribers.find(s => s.id === id) || this.clientDb.subscribers[0];
      const risk = calcRisk(sub);
      let targetedOffers = [];
      if (risk.tier === 'High') {
        targetedOffers = [
          { id: 'offer-20-vip', title: '🎁 20% Off Next 3 Boxes + Free VIP Mystery Snack/Accessory', description: 'Apply 20% savings on your next 3 monthly deliveries.', discountPercent: 20 },
          { id: 'offer-skip-free', title: '⏸️ Skip Next Month & Keep Current Lock-in Rate', description: 'Take a 30-day break with zero charge.', action: 'skip' }
        ];
      } else if (risk.tier === 'Medium') {
        targetedOffers = [
          { id: 'offer-15-off', title: '🌟 15% Off Your Next Delivery', description: 'Enjoy 15% off next month when you customize your box today.', discountPercent: 15 },
          { id: 'offer-swap-theme', title: '🔄 Swap to a Different Theme (Coffee, Snacks, Eco-Grooming)', description: 'Switch theme instantly without changing billing.', action: 'swap-theme' }
        ];
      } else {
        targetedOffers = [
          { id: 'offer-pause-flex', title: '⏸️ Pause Delivery for 30 Days (Zero Friction)', description: 'Pause risk-free instead of cancelling.', action: 'pause' }
        ];
      }
      return { subscriberId: id, churnRisk: risk, targetedOffers };
    }

    // POST /api/subscriber/:id/cancel
    if (method === 'POST' && urlPath.match(/^\/api\/subscriber\/[^\/]+\/cancel$/)) {
      const id = urlPath.split('/')[3];
      const sub = this.clientDb.subscribers.find(s => s.id === id);
      const risk = calcRisk(sub);
      const offer = body ? body.acceptedOffer : null;
      if (offer) {
        this.clientDb.retentionInterventions.unshift({
          id: 'int-' + Date.now(), subscriberId: id, subscriberName: sub.name, timestamp: new Date().toISOString(), riskScore: risk.score, riskTier: risk.tier, actionTaken: 'Retained', offerApplied: offer.title || 'Targeted Retention Discount', note: `Accepted offer: ${offer.title}`
        });
        if (offer.action === 'skip') { sub.status = 'Skipped'; sub.consecutiveSkips = (sub.consecutiveSkips || 0) + 1; }
        else { sub.status = 'Active'; sub.consecutiveSkips = 0; }
        saveDb();
        return { retained: true, message: 'Subscriber successfully retained!', subscriber: sub };
      } else {
        sub.status = 'Cancelled'; sub.nextRenewalDate = null; sub.packingCutoffDate = null;
        this.clientDb.retentionInterventions.unshift({
          id: 'int-' + Date.now(), subscriberId: id, subscriberName: sub.name, timestamp: new Date().toISOString(), riskScore: risk.score, riskTier: risk.tier, actionTaken: 'Cancelled', offerApplied: 'Declined all retention offers', note: `Proceeded with complete cancellation.`
        });
        saveDb();
        return { retained: false, message: 'Subscription has been cancelled.', subscriber: sub };
      }
    }

    // POST /api/subscriber/:id/rating
    if (method === 'POST' && urlPath.match(/^\/api\/subscriber\/[^\/]+\/rating$/)) {
      const id = urlPath.split('/')[3];
      const sub = this.clientDb.subscribers.find(s => s.id === id);
      if (sub && body && body.itemId) {
        if (!sub.itemRatings) sub.itemRatings = {};
        sub.itemRatings[body.itemId] = Number(body.rating);
        saveDb();
      }
      return { message: 'Item rating saved', itemRatings: sub ? sub.itemRatings : {} };
    }

    // GET /api/merchant/dashboard
    if (method === 'GET' && urlPath === '/api/merchant/dashboard') {
      const subs = this.clientDb.subscribers;
      const total = subs.length;
      const active = subs.filter(s => s.status === 'Active');
      const paused = subs.filter(s => s.status === 'Paused');
      const skipped = subs.filter(s => s.status === 'Skipped');
      const cancelled = subs.filter(s => s.status === 'Cancelled');
      let mrr = 0;
      active.forEach(s => { mrr += getPrice(s.planId, s.cadenceId).pricePerMonth; });
      const arpu = active.length ? Math.round(mrr / active.length) : 0;
      const churnRate = ((cancelled.length / total) * 100).toFixed(1);
      const riskCounts = { Low: 0, Medium: 0, High: 0 };
      const enriched = subs.map(s => {
        const risk = calcRisk(s);
        const p = getPrice(s.planId, s.cadenceId);
        if (s.status !== 'Cancelled') riskCounts[risk.tier]++;
        return { ...s, churnRiskScore: risk.score, churnRiskTier: risk.tier, riskFactors: risk.factors, monthlyRevenue: p.pricePerMonth };
      });
      const retainedCount = this.clientDb.retentionInterventions.filter(i => i.actionTaken === 'Retained').length;
      const totalInt = this.clientDb.retentionInterventions.length;
      const saveRate = totalInt ? ((retainedCount / totalInt) * 100).toFixed(1) : '100.0';

      return {
        metrics: {
          totalSubscribers: total, activeSubscribers: active.length, pausedSubscribers: paused.length, skippedSubscribers: skipped.length, cancelledSubscribers: cancelled.length, mrr, arpu, churnRate: `${churnRate}%`, retentionSaveRate: `${saveRate}%`, riskCounts
        },
        retentionInterventions: this.clientDb.retentionInterventions,
        subscribers: enriched
      };
    }

    return {};
  },

  // Load Initial Dataset
  async init() {
    const plansData = await this.apiCall('/api/plans');
    this.plans = plansData.plans || DEFAULT_SEED_DATA.plans;
    this.cadences = plansData.cadences || DEFAULT_SEED_DATA.cadences;

    const subsData = await this.apiCall('/api/subscribers');
    this.allSubscribers = subsData.subscribers || [];

    if (this.allSubscribers.length > 0) {
      this.currentSubscriberId = this.allSubscribers[0].id;
    }

    await this.loadCurrentSubscriber();
  },

  // Load Current Subscriber Details
  async loadCurrentSubscriber(id = null) {
    if (id) this.currentSubscriberId = id;
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}`);
    this.currentSubscriberData = res;
    if (res && res.subscriber) {
      this.selectedThemeKey = res.subscriber.theme;
      this.selectedCadenceId = res.subscriber.cadenceId;
      this.customizerSelectedItems = [...(res.subscriber.selectedItemIds || [])];
    }
    return res;
  },

  // Save Box Customization
  async saveCustomization(itemIds) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/customizer`, 'PUT', {
      selectedItemIds: itemIds,
      theme: this.selectedThemeKey
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Action: Skip, Pause, Resume, Gift, Change Cadence
  async performAction(action, payload = {}) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/action`, 'POST', {
      action,
      ...payload
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Churn Prevention Diagnosis
  async diagnoseCancellation() {
    return await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/diagnose-cancellation`, 'POST');
  },

  // Finalize Cancellation or Accept Offer
  async processCancellation(acceptedOffer = null) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/cancel`, 'POST', {
      acceptedOffer
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Submit Rating
  async submitRating(itemId, rating) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/rating`, 'POST', {
      itemId,
      rating
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Fetch Merchant Dashboard Metrics
  async fetchMerchantDashboard() {
    return await this.apiCall('/api/merchant/dashboard');
  }
};
