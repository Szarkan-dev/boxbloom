const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const DATA_FILE = path.join(__dirname, 'data', 'seed.json');

// In-memory data store hydrated from seed.json
let dbData = null;

function loadData() {
  try {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    dbData = JSON.parse(raw);
    console.log(`[Database] Loaded ${dbData.subscribers.length} subscribers from ${DATA_FILE}`);
  } catch (err) {
    console.error('[Database] Failed to load seed data:', err);
  }
}

function saveData() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(dbData, null, 2), 'utf8');
  } catch (err) {
    console.error('[Database] Failed to save seed data:', err);
  }
}

// Churn Risk Diagnostic Matrix Heuristic
function calculateChurnRisk(subscriber) {
  let score = 0;
  const factors = [];

  // Inactivity Factor
  const days = subscriber.daysSinceLastLogin || 0;
  if (days >= 30) {
    score += 35;
    factors.push(`High inactivity (${days} days since last login)`);
  } else if (days >= 15) {
    score += 20;
    factors.push(`Moderate inactivity (${days} days since last login)`);
  } else if (days >= 7) {
    score += 10;
    factors.push(`Recent inactivity (${days} days since last login)`);
  }

  // Consecutive Skips Factor
  const skips = subscriber.consecutiveSkips || 0;
  if (skips >= 2) {
    score += 30;
    factors.push(`Repeated skips (${skips} consecutive skipped months)`);
  } else if (skips === 1) {
    score += 15;
    factors.push(`One recent skipped delivery`);
  }

  // Support Sentiment Factor
  const sentiment = subscriber.supportSentimentScore || 5.0;
  if (sentiment < 2.5) {
    score += 25;
    factors.push(`Low support sentiment score (${sentiment.toFixed(1)}/5.0)`);
  } else if (sentiment < 3.5) {
    score += 15;
    factors.push(`Fair support sentiment score (${sentiment.toFixed(1)}/5.0)`);
  }

  // Tenure / Engagement Factor
  const boxes = subscriber.totalBoxesReceived || 0;
  if (boxes < 3) {
    score += 10;
    factors.push(`Early onboarding phase (${boxes} boxes received)`);
  }

  // Cap score at 100
  score = Math.min(100, score);

  let tier = 'Low';
  if (score >= 60) tier = 'High';
  else if (score >= 30) tier = 'Medium';

  return { score, tier, factors };
}

// Calculate Plan Price based on Cadence
function getPlanPrice(planId, cadenceId) {
  const plan = dbData.plans.find(p => p.id === planId) || dbData.plans[1];
  const cadence = dbData.cadences.find(c => c.id === cadenceId) || dbData.cadences[0];
  const discountMultiplier = 1 - (cadence.discountPercent / 100);
  const pricePerMonth = Math.round(plan.price * discountMultiplier);
  return { basePrice: plan.price, pricePerMonth, totalPrice: pricePerMonth * cadence.monthsInterval, cadenceName: cadence.name };
}

// MIME Types for Static File Server
const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.js': 'text/javascript; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

// Main Request Handler
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;

  // Enable CORS headers for prototype API flexibility
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  // JSON Helper
  const sendJSON = (statusCode, data) => {
    res.writeHead(statusCode, { 'Content-Type': 'application/json; charset=UTF-8' });
    res.end(JSON.stringify(data));
  };

  // Helper to parse POST/PUT body
  const getBody = (callback) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const json = body ? JSON.parse(body) : {};
        callback(null, json);
      } catch (err) {
        callback(err, null);
      }
    });
  };

  // --- API ROUTES ---

  // GET /api/plans
  if (req.method === 'GET' && pathname === '/api/plans') {
    return sendJSON(200, { plans: dbData.plans, cadences: dbData.cadences });
  }

  // GET /api/catalog/:theme
  if (req.method === 'GET' && pathname.startsWith('/api/catalog/')) {
    const themeKey = pathname.split('/')[3];
    const catalog = dbData.catalogs[themeKey];
    if (!catalog) return sendJSON(404, { error: 'Theme catalog not found' });
    return sendJSON(200, catalog);
  }

  // GET /api/subscribers
  if (req.method === 'GET' && pathname === '/api/subscribers') {
    const list = dbData.subscribers.map(sub => {
      const risk = calculateChurnRisk(sub);
      const pricing = getPlanPrice(sub.planId, sub.cadenceId);
      return {
        ...sub,
        churnRiskScore: risk.score,
        churnRiskTier: risk.tier,
        riskFactors: risk.factors,
        monthlyRevenue: pricing.pricePerMonth
      };
    });
    return sendJSON(200, { subscribers: list });
  }

  // GET /api/subscriber/:id
  if (req.method === 'GET' && pathname.startsWith('/api/subscriber/')) {
    const parts = pathname.split('/');
    if (parts.length === 4 && parts[2] === 'subscriber') {
      const id = parts[3];
      const sub = dbData.subscribers.find(s => s.id === id);
      if (!sub) return sendJSON(404, { error: 'Subscriber not found' });

      const risk = calculateChurnRisk(sub);
      const pricing = getPlanPrice(sub.planId, sub.cadenceId);
      const catalog = dbData.catalogs[sub.theme];
      const plan = dbData.plans.find(p => p.id === sub.planId);

      return sendJSON(200, {
        subscriber: sub,
        plan,
        pricing,
        catalog,
        churnRisk: risk
      });
    }
  }

  // PUT /api/subscriber/:id/customizer
  if (req.method === 'PUT' && pathname.match(/^\/api\/subscriber\/[^\/]+\/customizer$/)) {
    const id = pathname.split('/')[3];
    getBody((err, body) => {
      if (err) return sendJSON(400, { error: 'Invalid JSON' });
      const sub = dbData.subscribers.find(s => s.id === id);
      if (!sub) return sendJSON(404, { error: 'Subscriber not found' });

      if (body.selectedItemIds && Array.isArray(body.selectedItemIds)) {
        sub.selectedItemIds = body.selectedItemIds;
      }
      if (body.planId) sub.planId = body.planId;
      if (body.theme) sub.theme = body.theme;

      saveData();
      return sendJSON(200, { message: 'Box customization saved successfully', subscriber: sub });
    });
    return;
  }

  // POST /api/subscriber/:id/action (skip, pause, resume, gift, cadence)
  if (req.method === 'POST' && pathname.match(/^\/api\/subscriber\/[^\/]+\/action$/)) {
    const id = pathname.split('/')[3];
    getBody((err, body) => {
      if (err) return sendJSON(400, { error: 'Invalid JSON' });
      const sub = dbData.subscribers.find(s => s.id === id);
      if (!sub) return sendJSON(404, { error: 'Subscriber not found' });

      const action = body.action;

      if (action === 'skip') {
        sub.status = 'Skipped';
        sub.consecutiveSkips = (sub.consecutiveSkips || 0) + 1;
        // Shift next renewal date by 30 days
        const curDate = sub.nextRenewalDate ? new Date(sub.nextRenewalDate) : new Date();
        curDate.setDate(curDate.getDate() + 30);
        sub.nextRenewalDate = curDate.toISOString().split('T')[0];
        
        const cutoff = new Date(curDate);
        cutoff.setDate(cutoff.getDate() - 2);
        sub.packingCutoffDate = cutoff.toISOString().split('T')[0];
      } else if (action === 'pause') {
        const pauseDays = body.days || 30;
        sub.status = 'Paused';
        const curDate = sub.nextRenewalDate ? new Date(sub.nextRenewalDate) : new Date();
        curDate.setDate(curDate.getDate() + pauseDays);
        sub.nextRenewalDate = curDate.toISOString().split('T')[0];
        
        const cutoff = new Date(curDate);
        cutoff.setDate(cutoff.getDate() - 2);
        sub.packingCutoffDate = cutoff.toISOString().split('T')[0];
      } else if (action === 'resume') {
        sub.status = 'Active';
        sub.consecutiveSkips = 0;
        const curDate = new Date();
        curDate.setDate(curDate.getDate() + 14); // Next box in 14 days
        sub.nextRenewalDate = curDate.toISOString().split('T')[0];
        
        const cutoff = new Date(curDate);
        cutoff.setDate(cutoff.getDate() - 2);
        sub.packingCutoffDate = cutoff.toISOString().split('T')[0];
      } else if (action === 'gift') {
        sub.giftingDetails = {
          recipientName: body.recipientName || 'Friend',
          recipientAddress: body.recipientAddress || '123 Sunshine Way',
          giftMessage: body.giftMessage || 'Enjoy this month\'s BoxBloom on me!'
        };
      } else if (action === 'change-cadence') {
        if (body.cadenceId) sub.cadenceId = body.cadenceId;
      }

      saveData();
      return sendJSON(200, { message: `Action '${action}' processed successfully`, subscriber: sub });
    });
    return;
  }

  // POST /api/subscriber/:id/diagnose-cancellation
  if (req.method === 'POST' && pathname.match(/^\/api\/subscriber\/[^\/]+\/diagnose-cancellation$/)) {
    const id = pathname.split('/')[3];
    const sub = dbData.subscribers.find(s => s.id === id);
    if (!sub) return sendJSON(404, { error: 'Subscriber not found' });

    const risk = calculateChurnRisk(sub);
    let targetedOffers = [];

    if (risk.tier === 'High') {
      targetedOffers = [
        {
          id: 'offer-20-vip',
          title: '🎁 20% Off Next 3 Boxes + Free VIP Mystery Snack/Accessory',
          description: 'Stay with us and instantly apply 20% savings on your next 3 monthly deliveries.',
          discountPercent: 20
        },
        {
          id: 'offer-skip-free',
          title: '⏸️ Skip Next Month & Keep Current Lock-in Rate',
          description: 'Take a 30-day break with zero charge and retain your existing locked-in price tier.',
          action: 'skip'
        }
      ];
    } else if (risk.tier === 'Medium') {
      targetedOffers = [
        {
          id: 'offer-15-off',
          title: '🌟 15% Off Your Next Delivery',
          description: 'We love having you! Enjoy 15% off next month when you customize your box today.',
          discountPercent: 15
        },
        {
          id: 'offer-swap-theme',
          title: '🔄 Swap to a Different Theme (Coffee, Snacks, Eco-Grooming)',
          description: 'Bored of your current box? Switch theme instantly without changing your subscription billing.',
          action: 'swap-theme'
        }
      ];
    } else {
      targetedOffers = [
        {
          id: 'offer-pause-flex',
          title: '⏸️ Pause Delivery for 30 Days (Zero Friction)',
          description: 'Going on vacation? Pause risk-free instead of cancelling.',
          action: 'pause'
        }
      ];
    }

    return sendJSON(200, {
      subscriberId: id,
      churnRisk: risk,
      targetedOffers
    });
  }

  // POST /api/subscriber/:id/cancel
  if (req.method === 'POST' && pathname.match(/^\/api\/subscriber\/[^\/]+\/cancel$/)) {
    const id = pathname.split('/')[3];
    getBody((err, body) => {
      if (err) return sendJSON(400, { error: 'Invalid JSON' });
      const sub = dbData.subscribers.find(s => s.id === id);
      if (!sub) return sendJSON(404, { error: 'Subscriber not found' });

      const risk = calculateChurnRisk(sub);
      const acceptedOffer = body.acceptedOffer;

      if (acceptedOffer) {
        // Retention Save!
        dbData.retentionInterventions.unshift({
          id: 'int-' + Date.now(),
          subscriberId: id,
          subscriberName: sub.name,
          timestamp: new Date().toISOString(),
          riskScore: risk.score,
          riskTier: risk.tier,
          actionTaken: 'Retained',
          offerApplied: acceptedOffer.title || 'Targeted Retention Discount',
          note: `Subscriber accepted retention offer: ${acceptedOffer.title}`
        });

        if (acceptedOffer.action === 'skip') {
          sub.status = 'Skipped';
          sub.consecutiveSkips = (sub.consecutiveSkips || 0) + 1;
        } else {
          sub.status = 'Active';
          sub.consecutiveSkips = 0; // reset risk
        }
        sub.supportSentimentScore = Math.min(5.0, (sub.supportSentimentScore || 3.0) + 1.0);

        saveData();
        return sendJSON(200, {
          retained: true,
          message: 'Subscriber successfully retained! Retention incentive applied.',
          subscriber: sub
        });
      } else {
        // Final Cancellation
        sub.status = 'Cancelled';
        sub.nextRenewalDate = null;
        sub.packingCutoffDate = null;

        dbData.retentionInterventions.unshift({
          id: 'int-' + Date.now(),
          subscriberId: id,
          subscriberName: sub.name,
          timestamp: new Date().toISOString(),
          riskScore: risk.score,
          riskTier: risk.tier,
          actionTaken: 'Cancelled',
          offerApplied: 'Declined all retention offers',
          note: `Subscriber proceeded with complete account cancellation.`
        });

        saveData();
        return sendJSON(200, {
          retained: false,
          message: 'Subscription has been cancelled.',
          subscriber: sub
        });
      }
    });
    return;
  }

  // POST /api/subscriber/:id/rating
  if (req.method === 'POST' && pathname.match(/^\/api\/subscriber\/[^\/]+\/rating$/)) {
    const id = pathname.split('/')[3];
    getBody((err, body) => {
      if (err) return sendJSON(400, { error: 'Invalid JSON' });
      const sub = dbData.subscribers.find(s => s.id === id);
      if (!sub) return sendJSON(404, { error: 'Subscriber not found' });

      if (!sub.itemRatings) sub.itemRatings = {};
      if (body.itemId && body.rating) {
        sub.itemRatings[body.itemId] = Number(body.rating);
      }

      saveData();
      return sendJSON(200, { message: 'Item rating saved', itemRatings: sub.itemRatings });
    });
    return;
  }

  // GET /api/merchant/dashboard
  if (req.method === 'GET' && pathname === '/api/merchant/dashboard') {
    const subs = dbData.subscribers;
    const total = subs.length;
    const active = subs.filter(s => s.status === 'Active');
    const paused = subs.filter(s => s.status === 'Paused');
    const skipped = subs.filter(s => s.status === 'Skipped');
    const cancelled = subs.filter(s => s.status === 'Cancelled');

    // Calculate MRR
    let mrr = 0;
    active.forEach(s => {
      const p = getPlanPrice(s.planId, s.cadenceId);
      mrr += p.pricePerMonth;
    });

    const arpu = active.length ? Math.round(mrr / active.length) : 0;
    const churnRate = ((cancelled.length / total) * 100).toFixed(1);

    // Risk Tiers distribution
    const riskCounts = { Low: 0, Medium: 0, High: 0 };
    const enrichedSubscribers = subs.map(s => {
      const risk = calculateChurnRisk(s);
      const p = getPlanPrice(s.planId, s.cadenceId);
      if (s.status === 'Active' || s.status === 'Skipped' || s.status === 'Paused') {
        riskCounts[risk.tier]++;
      }
      return {
        ...s,
        churnRiskScore: risk.score,
        churnRiskTier: risk.tier,
        riskFactors: risk.factors,
        monthlyRevenue: p.pricePerMonth
      };
    });

    const totalRetained = dbData.retentionInterventions.filter(i => i.actionTaken === 'Retained').length;
    const totalInterventions = dbData.retentionInterventions.length;
    const retentionSaveRate = totalInterventions ? ((totalRetained / totalInterventions) * 100).toFixed(1) : '100.0';

    return sendJSON(200, {
      metrics: {
        totalSubscribers: total,
        activeSubscribers: active.length,
        pausedSubscribers: paused.length,
        skippedSubscribers: skipped.length,
        cancelledSubscribers: cancelled.length,
        mrr,
        arpu,
        churnRate: `${churnRate}%`,
        retentionSaveRate: `${retentionSaveRate}%`,
        riskCounts
      },
      retentionInterventions: dbData.retentionInterventions,
      subscribers: enrichedSubscribers
    });
  }

  // --- STATIC FILE SERVER ---
  let filePath = path.join(__dirname, 'public', pathname === '/' ? 'index.html' : pathname);
  
  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html for SPA routing if path doesn't have an extension
      if (!path.extname(pathname)) {
        filePath = path.join(__dirname, 'public', 'index.html');
      } else {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=UTF-8' });
        res.end('404 Not Found');
        return;
      }
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain; charset=UTF-8' });
        res.end('500 Server Error');
        return;
      }
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    });
  });
});

// Load seed dataset before listening
loadData();

server.listen(PORT, () => {
  console.log(`=================================================`);
  console.log(`🌸 BoxBloom Production Release Server Ready!`);
  console.log(`🌐 Server running at: http://localhost:${PORT}`);
  console.log(`=================================================`);
});
