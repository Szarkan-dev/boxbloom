/**
 * BoxBloom Central State & REST API Client
 */

const State = {
  currentSubscriberId: 'sub-101',
  currentSubscriberData: null,
  allSubscribers: [],
  plans: [],
  cadences: [],
  selectedThemeKey: 'artisan-coffee',
  selectedCadenceId: 'monthly',
  customizerSelectedItems: [],
  isLiveServerFallback: false,

  // API Call Wrapper with Standalone Live Server Fallback
  async apiCall(endpoint, method = 'GET', body = null) {
    const isLiveServer = window.location.port === '5500' || window.location.port === '8080' || window.location.protocol === 'file:';
    const baseUrl = isLiveServer ? 'http://localhost:3000' : '';
    
    const options = {
      method,
      headers: { 'Content-Type': 'application/json' }
    };
    if (body) options.body = JSON.stringify(body);

    try {
      const res = await fetch(baseUrl + endpoint, options);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      this.isLiveServerFallback = false;
      return await res.json();
    } catch (err) {
      console.warn(`[API] Server unavailable on ${endpoint}. Operating in standalone Live Server mode.`);
      this.isLiveServerFallback = true;
      return this.fallbackHandler(endpoint, method, body);
    }
  },

  // In-memory / LocalStorage Fallback database
  fallbackHandler(endpoint, method, body) {
    let mock = JSON.parse(localStorage.getItem('boxbloom_mock_db'));
    if (!mock) {
      mock = {
        plans: [
          { id: "mini", name: "Mini Starter", price: 19, itemCount: 3, description: "Perfect for essentials & quick monthly discovery.", popular: false },
          { id: "classic", name: "Classic Bloom", price: 39, itemCount: 5, description: "Our most popular balanced monthly box experience.", popular: true },
          { id: "deluxe", name: "Deluxe Reserve", price: 59, itemCount: 7, description: "Ultimate luxury box loaded with premium selections.", popular: false }
        ],
        cadences: [
          { id: "monthly", name: "Monthly", discountPercent: 0, monthsInterval: 1 },
          { id: "bimonthly", name: "Every 2 Months", discountPercent: 5, monthsInterval: 2 },
          { id: "quarterly", name: "Every 3 Months", discountPercent: 10, monthsInterval: 3 }
        ],
        catalogs: {
          "artisan-coffee": {
            name: "Artisan Coffee Roasters",
            description: "Hand-picked single origins and micro-lot roasts.",
            items: [
              { id: "c1", name: "Ethiopian Yirgacheffe", category: "Light Roast", rating: 4.8, tag: "Top Rated", image: "☕" },
              { id: "c2", name: "Guatemalan Antigua", category: "Medium Roast", rating: 4.7, tag: "Customer Favorite", image: "☕" },
              { id: "c3", name: "Sumatra Mandheling", category: "Dark Roast", rating: 4.6, tag: "Bold & Rich", image: "☕" },
              { id: "c4", name: "Colombian Supremo Organic", category: "Medium Roast", rating: 4.9, tag: "Organic", image: "🌿" },
              { id: "c5", name: "Cold Brew Coarse Blend", category: "Specialty", rating: 4.5, tag: "Seasonal", image: "🧊" },
              { id: "c6", name: "French Roast Espresso", category: "Dark Roast", rating: 4.4, tag: "Intense", image: "☕" },
              { id: "c7", name: "Hand-carved Wooden Scoop", category: "Accessory", rating: 4.9, tag: "Crafted", image: "🥄" },
              { id: "c8", name: "Unbleached Cone Filters (100x)", category: "Accessory", rating: 4.8, tag: "Essential", image: "📄" }
            ]
          },
          "gourmet-snacks": {
            name: "Gourmet Snacks",
            description: "Artisanal, non-GMO sweet and savory bites.",
            items: [
              { id: "s1", name: "Truffle & Sea Salt Almonds", category: "Savory", rating: 4.9, tag: "Best Seller", image: "🥜" },
              { id: "s2", name: "Dark Chocolate Matcha Bites", category: "Sweet", rating: 4.8, tag: "Antioxidant", image: "🍫" },
              { id: "s3", name: "Organic Dried Mango Strips", category: "Fruity", rating: 4.7, tag: "No Sugar Added", image: "🥭" },
              { id: "s4", name: "Smoked Paprika Cashews", category: "Savory", rating: 4.6, tag: "Spicy", image: "🌶️" },
              { id: "s5", name: "Artisanal Grass-Fed Jerky", category: "Protein", rating: 4.8, tag: "High Protein", image: "🥩" },
              { id: "s6", name: "Freeze-Dried Strawberry Crunch", category: "Sweet", rating: 4.5, tag: "Crispy", image: "🍓" },
              { id: "s7", name: "Gluten-Free Oats & Honey Cluster", category: "Granola", rating: 4.7, tag: "Gluten-Free", image: "🍯" },
              { id: "s8", name: "Spiced Rosemary Pecan Mix", category: "Savory", rating: 4.9, tag: "Gourmet", image: "🌿" }
            ]
          },
          "eco-grooming": {
            name: "Eco-Grooming",
            description: "Zero-waste, natural self-care & personal essentials.",
            items: [
              { id: "g1", name: "Bamboo Toothbrush Pack (4x)", category: "Dental", rating: 4.8, tag: "Biodegradable", image: "🪥" },
              { id: "g2", name: "Tea Tree Oil Shampoo Bar", category: "Haircare", rating: 4.7, tag: "Plastic-Free", image: "🧼" },
              { id: "g3", name: "All-Natural Citrus Deodorant", category: "Body", rating: 4.6, tag: "Aluminum-Free", image: "🍋" },
              { id: "g4", name: "Organic Jojoba Facial Serum", category: "Skincare", rating: 4.9, tag: "Cold-Pressed", image: "💧" },
              { id: "g5", name: "Natural Konjac Cleansing Sponge", category: "Skincare", rating: 4.8, tag: "Gentle Exfoliant", image: "🧽" },
              { id: "g6", name: "Eucalyptus Mint Lip Balm", category: "Lip Care", rating: 4.7, tag: "Organic Shea", image: "💄" },
              { id: "g7", name: "Recycled Aluminum Safety Razor", category: "Shaving", rating: 4.9, tag: "Zero Waste", image: "🪒" },
              { id: "g8", name: "Charcoal Detox Body Soap Bar", category: "Body", rating: 4.7, tag: "Purifying", image: "🫧" }
            ]
          }
        },
        subscribers: [
          {
            id: "sub-101",
            name: "Sarah Jenkins",
            email: "sarah.j@example.com",
            theme: "artisan-coffee",
            planId: "classic",
            cadenceId: "monthly",
            status: "Active",
            daysSinceLastLogin: 18,
            consecutiveSkips: 1,
            totalBoxesReceived: 10,
            supportSentimentScore: 2.2,
            selectedItemIds: ["c1", "c2", "c4", "c7", "c8"],
            nextRenewalDate: new Date(Date.now() + 4*86400000).toISOString().split('T')[0],
            packingCutoffDate: new Date(Date.now() + 2*86400000).toISOString().split('T')[0]
          }
        ],
        retentionInterventions: []
      };
      localStorage.setItem('boxbloom_mock_db', JSON.stringify(mock));
    }

    const calcRisk = (s) => {
      let score = 0;
      const factors = [];
      const d = s.daysSinceLastLogin || 0;
      if (d >= 30) { score += 35; factors.push({ name: 'High Login Inactivity', points: 35, detail: `${d} days inactive` }); }
      else if (d >= 15) { score += 20; factors.push({ name: 'Moderate Inactivity', points: 20, detail: `${d} days inactive` }); }
      else if (d >= 7) { score += 10; factors.push({ name: 'Recent Inactivity', points: 10, detail: `${d} days inactive` }); }

      const sk = s.consecutiveSkips || 0;
      if (sk >= 2) { score += 30; factors.push({ name: 'Repeated Skips', points: 30, detail: `${sk} consecutive skips` }); }
      else if (sk === 1) { score += 15; factors.push({ name: 'Recent Skip', points: 15, detail: `1 recent skip` }); }

      const sent = s.supportSentimentScore !== undefined ? s.supportSentimentScore : 5.0;
      if (sent < 2.5) { score += 25; factors.push({ name: 'Low Support Sentiment', points: 25, detail: `Score: ${sent.toFixed(1)}` }); }
      else if (sent < 3.5) { score += 15; factors.push({ name: 'Fair Support Sentiment', points: 15, detail: `Score: ${sent.toFixed(1)}` }); }

      if ((s.totalBoxesReceived || 0) < 3) { score += 10; factors.push({ name: 'Early Onboarding Risk', points: 10, detail: `Early phase` }); }

      score = Math.min(100, score);
      let tier = 'Low';
      if (score >= 60) tier = 'High';
      else if (score >= 30) tier = 'Medium';
      return { score, tier, factors };
    };

    if (endpoint === '/api/plans') return { plans: mock.plans, cadences: mock.cadences };
    if (endpoint.startsWith('/api/catalog/')) {
      const key = endpoint.split('/')[3];
      return mock.catalogs[key] || mock.catalogs['artisan-coffee'];
    }
    if (endpoint === '/api/subscribers') {
      return { subscribers: mock.subscribers.map(s => ({ ...s, churnRiskScore: calcRisk(s).score, churnRiskTier: calcRisk(s).tier, monthlyRevenue: 39 })) };
    }
    if (endpoint === '/api/demo/reset-scenario') {
      let sarah = mock.subscribers.find(s => s.id === 'sub-101');
      if (!sarah) { sarah = { id: 'sub-101' }; mock.subscribers.unshift(sarah); }
      sarah.name = "Sarah Jenkins";
      sarah.email = "sarah.j@example.com";
      sarah.theme = "artisan-coffee";
      sarah.planId = "classic";
      sarah.cadenceId = "monthly";
      sarah.status = "Active";
      sarah.daysSinceLastLogin = 18;
      sarah.consecutiveSkips = 1;
      sarah.supportSentimentScore = 2.2;
      sarah.totalBoxesReceived = 10;
      sarah.selectedItemIds = ["c1", "c2", "c4", "c7", "c8"];
      sarah.nextRenewalDate = new Date(Date.now() + 4*86400000).toISOString().split('T')[0];
      sarah.packingCutoffDate = new Date(Date.now() + 2*86400000).toISOString().split('T')[0];
      localStorage.setItem('boxbloom_mock_db', JSON.stringify(mock));
      return { message: 'Demo scenario initialized', subscriber: sarah, churnRisk: calcRisk(sarah) };
    }
    if (endpoint.startsWith('/api/subscriber/')) {
      const parts = endpoint.split('/');
      const id = parts[3];
      const sub = mock.subscribers.find(s => s.id === id) || mock.subscribers[0];
      const risk = calcRisk(sub);

      if (parts.length === 4) {
        return {
          subscriber: sub,
          plan: mock.plans.find(p => p.id === sub.planId) || mock.plans[1],
          pricing: { basePrice: 39, pricePerMonth: 39, totalPrice: 39, cadenceName: 'Monthly' },
          catalog: mock.catalogs[sub.theme] || mock.catalogs['artisan-coffee'],
          churnRisk: risk
        };
      }
      if (endpoint.endsWith('/diagnose-cancellation')) {
        return {
          subscriberId: id,
          churnRisk: risk,
          targetedOffers: [
            { id: 'offer-skip-vip', title: '☕ Skip October Box & Keep 15% VIP Discount', description: 'Take a 30-day break with zero charge and retain your 15% VIP subscriber lock-in price.', action: 'skip', discountPercent: 15 },
            { id: 'offer-20-vip', title: '🎁 20% Off Next 3 Boxes + Free VIP Mystery Snack/Accessory', description: 'Apply 20% savings on your next 3 monthly dispatches.', discountPercent: 20 }
          ]
        };
      }
      if (endpoint.endsWith('/cancel')) {
        if (body && body.acceptedOffer) {
          sub.status = body.acceptedOffer.action === 'skip' ? 'Skipped' : 'Active';
          mock.retentionInterventions.unshift({
            id: 'int-' + Date.now(),
            subscriberName: sub.name,
            timestamp: new Date().toISOString(),
            riskScore: risk.score,
            riskTier: risk.tier,
            actionTaken: 'Retained',
            offerApplied: body.acceptedOffer.title
          });
          localStorage.setItem('boxbloom_mock_db', JSON.stringify(mock));
          return { retained: true, message: 'Subscriber successfully retained!', subscriber: sub };
        } else {
          sub.status = 'Cancelled';
          mock.retentionInterventions.unshift({
            id: 'int-' + Date.now(),
            subscriberName: sub.name,
            timestamp: new Date().toISOString(),
            riskScore: risk.score,
            riskTier: risk.tier,
            actionTaken: 'Cancelled',
            offerApplied: 'Declined all retention offers'
          });
          localStorage.setItem('boxbloom_mock_db', JSON.stringify(mock));
          return { retained: false, message: 'Subscription cancelled.', subscriber: sub };
        }
      }
      if (endpoint.endsWith('/action')) {
        if (body.action === 'skip') {
          sub.status = 'Skipped';
          sub.consecutiveSkips = (sub.consecutiveSkips || 0) + 1;
        } else if (body.action === 'pause') {
          sub.status = 'Paused';
        } else if (body.action === 'resume') {
          sub.status = 'Active';
          sub.consecutiveSkips = 0;
        }
        localStorage.setItem('boxbloom_mock_db', JSON.stringify(mock));
        return { message: `Action ${body.action} saved`, subscriber: sub };
      }
    }
    if (endpoint === '/api/merchant/dashboard') {
      return {
        metrics: {
          totalSubscribers: mock.subscribers.length,
          activeSubscribers: mock.subscribers.filter(s => s.status === 'Active').length,
          pausedSubscribers: mock.subscribers.filter(s => s.status === 'Paused').length,
          skippedSubscribers: mock.subscribers.filter(s => s.status === 'Skipped').length,
          cancelledSubscribers: mock.subscribers.filter(s => s.status === 'Cancelled').length,
          mrr: 847,
          arpu: 42,
          churnRate: '4.0%',
          retentionSaveRate: '100.0%',
          riskCounts: { Low: 0, Medium: 0, High: 1 }
        },
        retentionInterventions: mock.retentionInterventions,
        subscribers: mock.subscribers.map(s => ({ ...s, churnRiskScore: calcRisk(s).score, churnRiskTier: calcRisk(s).tier, monthlyRevenue: 39 }))
      };
    }
    return {};
  },

  // Load Initial Dataset
  async init() {
    const plansData = await this.apiCall('/api/plans');
    this.plans = plansData.plans;
    this.cadences = plansData.cadences;

    const subsData = await this.apiCall('/api/subscribers');
    this.allSubscribers = subsData.subscribers;

    if (this.allSubscribers.length > 0) {
      this.currentSubscriberId = this.allSubscribers[0].id;
    }

    await this.loadCurrentSubscriber();
  },

  // Reset Exact Hackathon Demo Scenario (Passage 6)
  async resetDemoScenario() {
    const res = await this.apiCall('/api/demo/reset-scenario', 'POST');
    this.currentSubscriberId = 'sub-101';
    await this.loadCurrentSubscriber();
    return res;
  },

  // Load Current Subscriber Details
  async loadCurrentSubscriber(id = null) {
    if (id) this.currentSubscriberId = id;
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}`);
    this.currentSubscriberData = res;
    this.selectedThemeKey = res.subscriber.theme;
    this.selectedCadenceId = res.subscriber.cadenceId;
    this.customizerSelectedItems = [...res.subscriber.selectedItemIds];
    return res;
  },

  // Save Box Customization
  async saveCustomization(itemIds) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/customizer`, 'PUT', {
      selectedItemIds: itemIds,
      theme: this.selectedThemeKey,
      planId: this.currentSubscriberData.subscriber.planId,
      cadenceId: this.selectedCadenceId
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Action: Skip, Pause, Resume, Gift, Change Cadence
  async performAction(action, payload = {}) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/action`, 'POST', {
      action,
      ...payload
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Churn Prevention Diagnosis
  async diagnoseCancellation() {
    return await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/diagnose-cancellation`, 'POST');
  },

  // Finalize Cancellation or Accept Offer
  async processCancellation(acceptedOffer = null) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/cancel`, 'POST', {
      acceptedOffer
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Submit Rating
  async submitRating(itemId, rating) {
    const res = await this.apiCall(`/api/subscriber/${this.currentSubscriberId}/rating`, 'POST', {
      itemId,
      rating
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Simulate Risk parameters for Merchant Sandbox
  async simulateRisk(id, days, skips, sentiment) {
    const res = await this.apiCall(`/api/subscriber/${id}/simulate-risk`, 'POST', {
      daysSinceLastLogin: days,
      consecutiveSkips: skips,
      supportSentimentScore: sentiment
    });
    await this.loadCurrentSubscriber();
    return res;
  },

  // Fetch Merchant Dashboard Metrics
  async fetchMerchantDashboard() {
    return await this.apiCall('/api/merchant/dashboard');
  }
};
