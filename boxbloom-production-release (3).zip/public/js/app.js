/**
 * BoxBloom Main UI Application Controller
 */

document.addEventListener('DOMContentLoaded', async () => {
  // Initialize Theme
  initTheme();

  // Initialize State & Data
  try {
    await State.init();
    updateConnectionIndicator();
    renderSubscriberDropdown();
    renderSubscriberPortal();
    setupEventListeners();
    startCountdownTimer();
  } catch (err) {
    showToast('⚠️ Operating in standalone Live Server fallback mode');
    updateConnectionIndicator();
  }
});

/* --------------------------------------------------------------------------
   THEME & UI MODES
   -------------------------------------------------------------------------- */
function initTheme() {
  const savedTheme = localStorage.getItem('boxbloom_theme') || 'light';
  document.documentElement.setAttribute('data-theme', savedTheme);
  updateThemeIcon(savedTheme);
}

function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme');
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('boxbloom_theme', next);
  updateThemeIcon(next);
  showToast(`Switched to ${next} mode`);
}

function updateThemeIcon(theme) {
  const iconSpan = document.querySelector('#theme-toggle-btn .theme-icon');
  if (iconSpan) iconSpan.textContent = theme === 'dark' ? '☀️' : '🌙';
}

function updateConnectionIndicator() {
  const pill = document.getElementById('server-connection-indicator');
  if (!pill) return;
  if (State.isLiveServerFallback) {
    pill.textContent = '⚡ Live Server Mode';
    pill.className = 'connection-pill fallback';
  } else {
    pill.textContent = '🟢 Node Backend (3000)';
    pill.className = 'connection-pill online';
  }
}

/* --------------------------------------------------------------------------
   EVENT LISTENERS & ROUTING
   -------------------------------------------------------------------------- */
function setupEventListeners() {
  // Theme Toggle
  document.getElementById('theme-toggle-btn').addEventListener('click', toggleTheme);

  // Demo Launch Button
  document.getElementById('btn-run-demo-scenario').addEventListener('click', handleRunGuidedDemo);

  // View Switcher (Subscriber vs Merchant)
  document.querySelectorAll('.btn-toggle').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const view = e.currentTarget.dataset.view;
      document.querySelectorAll('.btn-toggle').forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');

      document.querySelectorAll('.view-section').forEach(s => s.classList.remove('active'));
      const targetView = document.getElementById(`view-${view}`);
      if (targetView) targetView.classList.add('active');

      if (view === 'merchant') {
        renderMerchantDashboard();
      }
    });
  });

  // Subscriber Switcher Dropdown
  const subSelect = document.getElementById('sub-select');
  subSelect.addEventListener('change', async (e) => {
    await State.loadCurrentSubscriber(e.target.value);
    renderSubscriberPortal();
    showToast(`Switched account: ${State.currentSubscriberData.subscriber.name}`);
  });

  // Tab Navigation
  document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      const tabId = e.currentTarget.dataset.tab;
      switchSubTab(tabId);
    });
  });

  // Quick Action Buttons
  document.getElementById('btn-quick-skip').addEventListener('click', handleQuickSkip);
  document.getElementById('btn-quick-pause').addEventListener('click', () => openModal('modal-pause'));
  document.getElementById('btn-confirm-pause').addEventListener('click', handleConfirmPause);
  document.getElementById('btn-quick-gift').addEventListener('click', () => openModal('modal-gift'));
  document.getElementById('btn-confirm-gift').addEventListener('click', handleConfirmGift);
  document.getElementById('btn-quick-resume').addEventListener('click', handleQuickResume);
  document.getElementById('btn-open-cancel').addEventListener('click', handleOpenChurnModal);
  document.getElementById('btn-final-cancel').addEventListener('click', handleFinalizeCancellation);

  // Customizer Controls
  document.getElementById('btn-save-customization').addEventListener('click', handleSaveCustomization);
  document.querySelectorAll('.btn-theme').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.btn-theme').forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      State.selectedThemeKey = e.currentTarget.dataset.themeKey;
      renderCustomizerCatalog();
    });
  });

  // Plans Cadence Toggle
  document.querySelectorAll('.btn-cadence').forEach(btn => {
    btn.addEventListener('click', (e) => {
      document.querySelectorAll('.btn-cadence').forEach(b => b.classList.remove('active'));
      e.currentTarget.classList.add('active');
      State.selectedCadenceId = e.currentTarget.dataset.cadence;
      renderPlansGrid();
    });
  });

  // Merchant Controls
  document.getElementById('btn-refresh-merchant').addEventListener('click', renderMerchantDashboard);
  document.getElementById('merchant-search-input').addEventListener('input', filterMerchantTable);
  document.getElementById('merchant-risk-filter').addEventListener('change', filterMerchantTable);

  // Simulator Controls
  ['sim-days', 'sim-skips', 'sim-sentiment'].forEach(id => {
    document.getElementById(id).addEventListener('input', updateSimResultDisplay);
  });
  document.getElementById('btn-apply-sim').addEventListener('click', handleApplySimulation);
}

/* --------------------------------------------------------------------------
   EXACT HACKATHON DEMO WORKFLOW (Passage 6 in Evaluation Brief)
   -------------------------------------------------------------------------- */
async function handleRunGuidedDemo() {
  try {
    await State.resetDemoScenario();
    renderSubscriberDropdown();
    renderSubscriberPortal();
    switchSubTab('tab-overview');
    showToast('🚀 Demo Mode Initialized: Sarah Jenkins (Artisan Coffee Box, High Risk)');
    
    // Automatically trigger Churn Prevention Modal after 600ms
    setTimeout(() => {
      handleOpenChurnModal();
    }, 600);
  } catch (err) {
    showToast('❌ Failed to launch demo scenario');
  }
}

function switchSubTab(tabId) {
  document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
  document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));

  const activeTabBtn = document.querySelector(`.nav-tab[data-tab="${tabId}"]`);
  const activePane = document.getElementById(tabId);

  if (activeTabBtn) activeTabBtn.classList.add('active');
  if (activePane) activePane.classList.add('active');

  if (tabId === 'tab-customizer') renderCustomizerCatalog();
  if (tabId === 'tab-plans') renderPlansGrid();
  if (tabId === 'tab-ratings') renderRatingsMatrix();
}

/* --------------------------------------------------------------------------
   SUBSCRIBER PORTAL RENDERING & STATE MACHINE VISUALIZER
   -------------------------------------------------------------------------- */
function renderSubscriberDropdown() {
  const select = document.getElementById('sub-select');
  select.innerHTML = '';
  State.allSubscribers.forEach(sub => {
    const opt = document.createElement('option');
    opt.value = sub.id;
    opt.textContent = `${sub.name} (${sub.status} - ${sub.churnRiskTier} Risk)`;
    if (sub.id === State.currentSubscriberId) opt.selected = true;
    select.appendChild(opt);
  });
}

function renderSubscriberPortal() {
  const data = State.currentSubscriberData;
  if (!data) return;

  const sub = data.subscriber;
  const plan = data.plan;
  const pricing = data.pricing;

  // Header Status Badge
  const badge = document.getElementById('sub-status-badge');
  badge.className = `badge badge-${sub.status.toLowerCase()}`;
  badge.textContent = sub.status;

  // State Machine Node Highlight
  ['active', 'skipped', 'paused', 'retained', 'cancelled'].forEach(nodeKey => {
    const el = document.getElementById(`sm-node-${nodeKey}`);
    if (el) el.classList.remove('active');
  });
  const currentSmNode = document.getElementById(`sm-node-${sub.status.toLowerCase()}`);
  if (currentSmNode) currentSmNode.classList.add('active');

  // Overview Card
  document.getElementById('overview-plan-title').textContent = `${plan.name} Box`;
  
  const statusPill = document.getElementById('overview-status-pill');
  statusPill.className = `badge badge-${sub.status.toLowerCase()}`;
  statusPill.textContent = sub.status;

  document.getElementById('overview-theme-name').textContent = data.catalog ? data.catalog.name : sub.theme;
  document.getElementById('overview-cadence').textContent = `${pricing.cadenceName} ($${pricing.pricePerMonth}/mo)`;
  document.getElementById('overview-item-count').textContent = `${plan.itemCount} Items per Box`;
  document.getElementById('overview-boxes-count').textContent = `${sub.totalBoxesReceived} Boxes Received`;

  // Toggle Resume Button
  const btnResume = document.getElementById('btn-quick-resume');
  if (sub.status === 'Paused' || sub.status === 'Skipped' || sub.status === 'Cancelled') {
    btnResume.classList.remove('hidden');
  } else {
    btnResume.classList.add('hidden');
  }

  // Gifting Banner
  const giftBanner = document.getElementById('gifting-banner');
  if (sub.giftingDetails) {
    giftBanner.classList.remove('hidden');
    document.getElementById('gift-recipient-name').textContent = sub.giftingDetails.recipientName;
  } else {
    giftBanner.classList.add('hidden');
  }

  // Timeline
  document.getElementById('timeline-cutoff-date').textContent = sub.packingCutoffDate || 'N/A';
  document.getElementById('timeline-renewal-date').textContent = sub.nextRenewalDate || 'N/A';
  
  if (sub.nextRenewalDate) {
    const dispatch = new Date(sub.nextRenewalDate);
    dispatch.setDate(dispatch.getDate() + 2);
    document.getElementById('timeline-dispatch-date').textContent = dispatch.toISOString().split('T')[0];
  } else {
    document.getElementById('timeline-dispatch-date').textContent = 'N/A';
  }

  // Overview Selected Items Grid
  renderOverviewItemsGrid();
}

function renderOverviewItemsGrid() {
  const data = State.currentSubscriberData;
  const grid = document.getElementById('overview-items-grid');
  grid.innerHTML = '';

  if (!data.catalog || !data.catalog.items) return;

  const selectedItems = data.catalog.items.filter(item => data.subscriber.selectedItemIds.includes(item.id));

  selectedItems.forEach(item => {
    const card = document.createElement('div');
    card.className = 'item-card selected';
    card.innerHTML = `
      <span class="item-badge-tag">${item.tag}</span>
      <div class="item-emoji">${item.image}</div>
      <div>
        <div class="item-name">${item.name}</div>
        <div class="item-cat">${item.category}</div>
      </div>
      <div class="item-rating">⭐ ${item.rating} / 5.0</div>
    `;
    grid.appendChild(card);
  });
}

/* --------------------------------------------------------------------------
   BOX CUSTOMIZER
   -------------------------------------------------------------------------- */
async function renderCustomizerCatalog() {
  const data = State.currentSubscriberData;
  const catalogRes = await State.apiCall(`/api/catalog/${State.selectedThemeKey}`);

  const maxItems = data.plan ? data.plan.itemCount : 5;
  document.getElementById('customizer-max').textContent = maxItems;
  document.getElementById('customizer-count').textContent = State.customizerSelectedItems.length;

  const grid = document.getElementById('customizer-catalog-grid');
  grid.innerHTML = '';

  catalogRes.items.forEach(item => {
    const isSelected = State.customizerSelectedItems.includes(item.id);
    const card = document.createElement('div');
    card.className = `item-card ${isSelected ? 'selected' : ''}`;
    card.onclick = () => toggleItemCustomization(item.id, maxItems);

    card.innerHTML = `
      <span class="item-badge-tag">${item.tag}</span>
      <div class="item-emoji">${item.image}</div>
      <div>
        <div class="item-name">${item.name}</div>
        <div class="item-cat">${item.category}</div>
      </div>
      <div class="flex-between" style="margin-top: 0.5rem;">
        <span class="item-rating">⭐ ${item.rating}</span>
        <button class="btn ${isSelected ? 'btn-danger' : 'btn-primary'}" style="padding: 0.2rem 0.6rem; font-size: 0.75rem;">
          ${isSelected ? 'Remove' : 'Select'}
        </button>
      </div>
    `;
    grid.appendChild(card);
  });
}

function toggleItemCustomization(itemId, maxItems) {
  const idx = State.customizerSelectedItems.indexOf(itemId);
  if (idx > -1) {
    State.customizerSelectedItems.splice(idx, 1);
  } else {
    if (State.customizerSelectedItems.length >= maxItems) {
      showToast(`⚠️ Maximum ${maxItems} items allowed for your ${State.currentSubscriberData.plan.name} plan!`);
      return;
    }
    State.customizerSelectedItems.push(itemId);
  }
  document.getElementById('customizer-count').textContent = State.customizerSelectedItems.length;
  renderCustomizerCatalog();
}

async function handleSaveCustomization() {
  try {
    await State.saveCustomization(State.customizerSelectedItems);
    renderSubscriberPortal();
    showToast('✨ Box customization saved successfully!');
    switchSubTab('tab-overview');
  } catch (err) {
    showToast('❌ Failed to save customization');
  }
}

/* --------------------------------------------------------------------------
   PLANS & PRICING
   -------------------------------------------------------------------------- */
function renderPlansGrid() {
  const grid = document.getElementById('plans-grid');
  grid.innerHTML = '';

  const cadence = State.cadences.find(c => c.id === State.selectedCadenceId) || State.cadences[0];
  const discountMultiplier = 1 - (cadence.discountPercent / 100);

  State.plans.forEach(plan => {
    const pricePerMonth = Math.round(plan.price * discountMultiplier);
    const isCurrentPlan = State.currentSubscriberData && State.currentSubscriberData.subscriber.planId === plan.id;

    const card = document.createElement('div');
    card.className = `plan-card ${plan.popular ? 'popular' : ''}`;
    card.innerHTML = `
      ${plan.popular ? '<span class="popular-badge">Most Popular</span>' : ''}
      <div>
        <h3 class="card-title">${plan.name}</h3>
        <p class="card-subtitle">${plan.description}</p>
        <div class="plan-price">$${pricePerMonth} <span>/ month</span></div>
        <p style="font-size: 0.8rem; color: var(--text-muted);">Billed ${cadence.name.toLowerCase()}</p>
      </div>

      <ul class="plan-features">
        <li>${plan.itemCount} Custom Box Items</li>
        <li>1-Click Free Skip & Pause</li>
        <li>Gift Box Redirection</li>
        <li>Priority Delivery Tracker</li>
      </ul>

      <button class="btn ${isCurrentPlan ? 'btn-secondary' : 'btn-primary'}" ${isCurrentPlan ? 'disabled' : ''} onclick="handlePlanSelect('${plan.id}')">
        ${isCurrentPlan ? 'Current Active Plan' : 'Switch to Plan'}
      </button>
    `;
    grid.appendChild(card);
  });
}

async function handlePlanSelect(planId) {
  try {
    State.currentSubscriberData.subscriber.planId = planId;
    await State.saveCustomization(State.customizerSelectedItems);
    renderSubscriberPortal();
    showToast(`💳 Plan updated to ${planId.toUpperCase()}!`);
    switchSubTab('tab-overview');
  } catch (err) {
    showToast('❌ Failed to update plan');
  }
}

/* --------------------------------------------------------------------------
   RATINGS MATRIX
   -------------------------------------------------------------------------- */
function renderRatingsMatrix() {
  const data = State.currentSubscriberData;
  const container = document.getElementById('ratings-matrix-container');
  container.innerHTML = '';

  if (!data.catalog || !data.catalog.items) return;

  data.catalog.items.forEach(item => {
    const currentRating = (data.subscriber.itemRatings && data.subscriber.itemRatings[item.id]) || 0;
    const card = document.createElement('div');
    card.className = 'rating-item-card';
    
    let starsHtml = '';
    for (let i = 1; i <= 5; i++) {
      starsHtml += `<span class="star ${i <= currentRating ? 'active' : ''}" onclick="submitItemRating('${item.id}', ${i})">★</span>`;
    }

    card.innerHTML = `
      <div style="display: flex; align-items: center; gap: 0.75rem;">
        <span style="font-size: 1.8rem;">${item.image}</span>
        <div>
          <div style="font-weight: 700; font-size: 0.9rem;">${item.name}</div>
          <div style="font-size: 0.75rem; color: var(--text-muted);">${item.category}</div>
        </div>
      </div>
      <div class="star-rating">${starsHtml}</div>
    `;
    container.appendChild(card);
  });
}

async function submitItemRating(itemId, rating) {
  try {
    await State.submitRating(itemId, rating);
    renderRatingsMatrix();
    showToast(`⭐ Rating ${rating}/5 saved! Preference engine updated.`);
  } catch (err) {
    showToast('❌ Failed to save rating');
  }
}

/* --------------------------------------------------------------------------
   QUICK ACTIONS & CHURN PREVENTION CANCELLATION MODAL
   -------------------------------------------------------------------------- */
async function handleQuickSkip() {
  if (confirm('Are you sure you want to skip next month\'s delivery? Zero fees will be charged.')) {
    try {
      await State.performAction('skip');
      renderSubscriberPortal();
      showToast('⏸️ Next month delivery skipped successfully.');
    } catch (err) {
      showToast('❌ Failed to skip delivery');
    }
  }
}

async function handleQuickResume() {
  try {
    await State.performAction('resume');
    renderSubscriberPortal();
    showToast('▶️ Subscription reactivated to Active state!');
  } catch (err) {
    showToast('❌ Failed to reactivate subscription');
  }
}

async function handleConfirmPause() {
  const duration = document.querySelector('input[name="pause-duration"]:checked').value;
  try {
    await State.performAction('pause', { days: Number(duration) });
    closeModal('modal-pause');
    renderSubscriberPortal();
    showToast(`🛑 Subscription paused for ${duration} days.`);
  } catch (err) {
    showToast('❌ Failed to pause subscription');
  }
}

async function handleConfirmGift() {
  const name = document.getElementById('gift-name').value;
  const address = document.getElementById('gift-address').value;
  const message = document.getElementById('gift-message').value;

  if (!name || !address) {
    showToast('⚠️ Please enter recipient name and address.');
    return;
  }

  try {
    await State.performAction('gift', { recipientName: name, recipientAddress: address, giftMessage: message });
    closeModal('modal-gift');
    renderSubscriberPortal();
    showToast(`🎁 Next box will be delivered to ${name}!`);
  } catch (err) {
    showToast('❌ Failed to set gift delivery');
  }
}

async function handleOpenChurnModal() {
  openModal('modal-churn');
  const res = await State.diagnoseCancellation();
  
  const riskTierSpan = document.getElementById('modal-risk-tier');
  riskTierSpan.className = `badge badge-risk-${res.churnRisk.tier.toLowerCase()}`;
  riskTierSpan.textContent = `${res.churnRisk.tier} Churn Risk (${res.churnRisk.score} Pts)`;

  // Itemized Weighted Factor Matrix
  const factorsMatrixGrid = document.getElementById('modal-risk-factors-matrix');
  factorsMatrixGrid.innerHTML = '';
  
  if (res.churnRisk.factors && res.churnRisk.factors.length > 0) {
    res.churnRisk.factors.forEach(f => {
      const row = document.createElement('div');
      row.className = 'factor-row';
      row.innerHTML = `
        <span class="factor-name">${f.name || f}</span>
        <span class="factor-pts">+${f.points || 15} pts</span>
      `;
      factorsMatrixGrid.appendChild(row);
    });
  } else {
    factorsMatrixGrid.innerHTML = '<div class="factor-row"><span class="factor-name">High engagement & recent portal activity</span><span class="factor-pts">0 pts</span></div>';
  }

  const offersContainer = document.getElementById('retention-offers-container');
  offersContainer.innerHTML = '';

  res.targetedOffers.forEach(offer => {
    const card = document.createElement('div');
    card.className = 'offer-card';
    card.onclick = () => acceptRetentionOffer(offer);
    card.innerHTML = `
      <div class="offer-title">${offer.title}</div>
      <div class="offer-desc">${offer.description}</div>
      <button class="btn btn-primary" style="margin-top: 0.5rem; width: 100%;">
        Accept This Retention Offer
      </button>
    `;
    offersContainer.appendChild(card);
  });
}

async function acceptRetentionOffer(offer) {
  try {
    const res = await State.processCancellation(offer);
    closeModal('modal-churn');
    renderSubscriberPortal();
    renderSubscriberDropdown();
    showToast(`✨ Churn Save! ${res.message}`);

    // If viewing Merchant Health, refresh live analytics
    if (document.getElementById('view-merchant').classList.contains('active')) {
      renderMerchantDashboard();
    }
  } catch (err) {
    showToast('❌ Action failed');
  }
}

async function handleFinalizeCancellation() {
  if (confirm('Are you completely sure you want to cancel your BoxBloom subscription? All perks will be lost.')) {
    try {
      const res = await State.processCancellation(null);
      closeModal('modal-churn');
      renderSubscriberPortal();
      renderSubscriberDropdown();
      showToast('❌ Subscription cancelled.');
    } catch (err) {
      showToast('❌ Cancellation failed');
    }
  }
}

/* --------------------------------------------------------------------------
   MERCHANT HEALTH DASHBOARD & SIMULATOR
   -------------------------------------------------------------------------- */
async function renderMerchantDashboard() {
  try {
    const res = await State.fetchMerchantDashboard();
    const m = res.metrics;

    document.getElementById('mrr-val').textContent = `$${m.mrr.toLocaleString()}`;
    document.getElementById('arpu-val').textContent = `$${m.arpu}`;
    document.getElementById('active-subs-val').textContent = m.activeSubscribers;
    document.getElementById('total-subs-val').textContent = m.totalSubscribers;
    document.getElementById('churn-rate-val').textContent = m.churnRate;
    document.getElementById('save-rate-val').textContent = m.retentionSaveRate;
    document.getElementById('high-risk-val').textContent = m.riskCounts.High;

    // Progress Bars
    const totalActive = m.activeSubscribers + m.pausedSubscribers + m.skippedSubscribers;
    document.getElementById('high-risk-count').textContent = m.riskCounts.High;
    document.getElementById('high-risk-bar').style.width = `${totalActive ? (m.riskCounts.High / totalActive) * 100 : 0}%`;

    document.getElementById('med-risk-count').textContent = m.riskCounts.Medium;
    document.getElementById('med-risk-bar').style.width = `${totalActive ? (m.riskCounts.Medium / totalActive) * 100 : 0}%`;

    document.getElementById('low-risk-count').textContent = m.riskCounts.Low;
    document.getElementById('low-risk-bar').style.width = `${totalActive ? (m.riskCounts.Low / totalActive) * 100 : 0}%`;

    // Intervention Logs
    const logContainer = document.getElementById('intervention-logs-list');
    logContainer.innerHTML = '';
    res.retentionInterventions.forEach(log => {
      const div = document.createElement('div');
      div.className = 'log-entry';
      div.innerHTML = `
        <div>
          <strong>${log.subscriberName || log.subscriberId}</strong>
          <span class="badge badge-${log.actionTaken === 'Retained' ? 'active' : 'cancelled'}">${log.actionTaken}</span>
          <div style="color: var(--text-muted); font-size: 0.75rem;">${log.offerApplied}</div>
        </div>
        <div style="text-align: right; font-size: 0.75rem; color: var(--text-muted);">
          ${new Date(log.timestamp).toLocaleDateString()}
        </div>
      `;
      logContainer.appendChild(div);
    });

    // Populate Table
    window.merchantSubscribersData = res.subscribers;
    filterMerchantTable();
  } catch (err) {
    showToast('❌ Failed to fetch merchant analytics');
  }
}

function filterMerchantTable() {
  const query = document.getElementById('merchant-search-input').value.toLowerCase();
  const riskFilter = document.getElementById('merchant-risk-filter').value;
  const tbody = document.getElementById('merchant-table-body');
  tbody.innerHTML = '';

  if (!window.merchantSubscribersData) return;

  const filtered = window.merchantSubscribersData.filter(s => {
    const matchesQuery = s.name.toLowerCase().includes(query) || s.email.toLowerCase().includes(query);
    const matchesRisk = riskFilter === 'ALL' || s.churnRiskTier === riskFilter;
    return matchesQuery && matchesRisk;
  });

  filtered.forEach(s => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>
        <strong>${s.name}</strong>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${s.email}</div>
      </td>
      <td>
        <div>${s.theme}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted);">${s.planId.toUpperCase()}</div>
      </td>
      <td><span class="badge badge-${s.status.toLowerCase()}">${s.status}</span></td>
      <td>${s.daysSinceLastLogin} days ago</td>
      <td>⭐ ${s.supportSentimentScore.toFixed(1)} / 5.0</td>
      <td><span class="badge badge-risk-${s.churnRiskTier.toLowerCase()}">${s.churnRiskTier} (${s.churnRiskScore} pts)</span></td>
      <td>$${s.monthlyRevenue}/mo</td>
      <td>
        <button class="btn btn-outline" style="padding: 0.2rem 0.5rem; font-size: 0.75rem;" onclick="openSimulatorModal('${s.id}')">
          🧪 Simulate Risk
        </button>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

/* --------------------------------------------------------------------------
   RISK SIMULATOR MODAL CONTROLLER
   -------------------------------------------------------------------------- */
function openSimulatorModal(id) {
  const sub = window.merchantSubscribersData.find(s => s.id === id);
  if (!sub) return;

  window.simulatingSubscriberId = id;
  document.getElementById('sim-days').value = sub.daysSinceLastLogin || 0;
  document.getElementById('sim-skips').value = sub.consecutiveSkips || 0;
  document.getElementById('sim-sentiment').value = sub.supportSentimentScore || 5.0;

  updateSimResultDisplay();
  openModal('modal-simulator');
}

function updateSimResultDisplay() {
  const days = Number(document.getElementById('sim-days').value);
  const skips = Number(document.getElementById('sim-skips').value);
  const sentiment = Number(document.getElementById('sim-sentiment').value);

  document.getElementById('sim-days-val').textContent = days;
  document.getElementById('sim-skips-val').textContent = skips;
  document.getElementById('sim-sentiment-val').textContent = sentiment.toFixed(1);

  let score = 0;
  if (days >= 30) score += 35; else if (days >= 15) score += 20; else if (days >= 7) score += 10;
  if (skips >= 2) score += 30; else if (skips === 1) score += 15;
  if (sentiment < 2.5) score += 25; else if (sentiment < 3.5) score += 15;

  score = Math.min(100, score);
  let tier = 'Low';
  if (score >= 60) tier = 'High'; else if (score >= 30) tier = 'Medium';

  document.getElementById('sim-tier').textContent = tier;
  document.getElementById('sim-score').textContent = score;
}

async function handleApplySimulation() {
  const id = window.simulatingSubscriberId;
  const days = Number(document.getElementById('sim-days').value);
  const skips = Number(document.getElementById('sim-skips').value);
  const sentiment = Number(document.getElementById('sim-sentiment').value);

  try {
    await State.simulateRisk(id, days, skips, sentiment);
    closeModal('modal-simulator');
    renderMerchantDashboard();
    showToast('🧪 Risk simulation applied!');
  } catch (err) {
    showToast('❌ Simulation update failed');
  }
}

/* --------------------------------------------------------------------------
   COUNTDOWN TIMER & MODALS & TOAST
   -------------------------------------------------------------------------- */
function startCountdownTimer() {
  setInterval(() => {
    const data = State.currentSubscriberData;
    if (!data || !data.subscriber || !data.subscriber.packingCutoffDate) return;

    const target = new Date(`${data.subscriber.packingCutoffDate}T23:59:59`).getTime();
    const now = new Date().getTime();
    const diff = target - now;

    if (diff > 0) {
      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const m = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));

      document.getElementById('timer-days').textContent = String(d).padStart(2, '0');
      document.getElementById('timer-hours').textContent = String(h).padStart(2, '0');
      document.getElementById('timer-mins').textContent = String(m).padStart(2, '0');
    }
  }, 1000);
}

function openModal(id) {
  document.getElementById(id).classList.remove('hidden');
}

function closeModal(id) {
  document.getElementById(id).classList.add('hidden');
}

function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.remove('hidden');
  setTimeout(() => toast.classList.add('hidden'), 3500);
}
